﻿using System;

namespace BotFrameworkDemo
{
    [Serializable]
    public class AgentMetaData
    {
        public bool IsAgent { get; set; }
    }
}