﻿namespace BotFrameworkDemo.Services
{
    public class BingSpellCheckSuggestion
    {
        public string Suggestion { get; set; }

        public double Score { get; set; }
    }
}
