﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HicomCore
{
    public class AuditHandler
    {
        private DbContext context;

        public AuditHandler(DbContext context)
        {
            this.context = context;
        }
        public Audit GetAudit(DbEntityEntry entry)
        {
            Audit audit = new Audit();
            int userId = 1;
            audit.SecurityUserId = userId;
            audit.TableName = GetTableName(entry);
            audit.PrimaryKey = GetKeyValue(entry);
          
            audit.EventDateTime = DateTime.UtcNow;
            
            //entry is Added 
            if (entry.State == EntityState.Added)
            {
              
                audit.EventType = 0;
            }
            //entry in deleted
            else if (entry.State == EntityState.Deleted)
            {

                audit.EventType = 3;
            }
            //entry is modified
            else if (entry.State == EntityState.Modified)
            {
                audit.EventType = 1;
            }
            
            return audit;
        }
        public int? GetKeyValue(DbEntityEntry entry)
        {
            var objectStateEntry = ((IObjectContextAdapter)context).ObjectContext.ObjectStateManager.GetObjectStateEntry(entry.Entity);
            int id = 0;
            if (objectStateEntry.EntityKey.EntityKeyValues != null)
                id = Convert.ToInt32(objectStateEntry.EntityKey.EntityKeyValues[0].Value);

            return id;
        }

        private string GetTableName(DbEntityEntry dbEntry)
        {
            TableAttribute tableAttr = dbEntry.Entity.GetType().GetCustomAttributes(typeof(TableAttribute), false).SingleOrDefault() as TableAttribute;
            string tableName = tableAttr != null ? tableAttr.Name : ((dbEntry.Entity.GetType()).BaseType).Name;
                //tableAttr != null ? tableAttr.Name : dbEntry.Entity.GetType().Name;
            return tableName;
        }
    }

   

}
