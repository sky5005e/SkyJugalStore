﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Web;
using IntermediatorBotSample.ViewModels;
using IntermediatorBot.DataModel;
namespace IntermediatorBotSample.Repository
{
    public class UserRepo
    {
       // DataModel.UserAgentBotDataEntities DB = new DataModel.UserAgentBotDataEntities();
        
        public string  ResetPassword(RegisterExternalBindingModel model)
        {
            using (var db = new UserAgentDBEntities())
            {

                var user = db.UserInformation.Where(s => s.Email == model.Email).FirstOrDefault();
                if(user!= null)
                {
                    user.Password = "Abc123!";
                }
                return "Update Successfully";
            }

        }

        public string RegisterUser(RegisterBindingModel model)
        {
            try
            {
                using (var db = new UserAgentDBEntities())
                {
                    // Create a new User object
                    UserInformation User = new UserInformation();
                    // Set the properties on the User object
                    User.Email = model.UserName;
                    User.FirstName = model.FirstName;
                    User.LastName = model.LastName;
                    User.Password = model.Password;
                    User.UserName = model.UserName;
                    User.created = DateTime.UtcNow;
                    // Add the UserLog object to UserLogs
                    db.UserInformation.Add(User);
                    // Save the changes to the database
                    db.SaveChanges();
                    //return "Saved Successfully";
                }
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
            return "true";
        }

        public bool ValidateUser(ViewModels.LoginModel model)
        {
            using (var db = new UserAgentDBEntities())
            {

                var user = db.UserInformation.Where(s => s.Email == model.UserName && s.Password == model.Password).FirstOrDefault();
                if (user != null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

        }
    }
}