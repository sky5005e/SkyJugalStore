//import { NgModule } from '@angular/core';
//import { APP_BASE_HREF } from '@angular/common';
//import { BrowserModule } from '@angular/platform-browser';
//import { ReactiveFormsModule } from '@angular/forms';
//import { HttpModule } from '@angular/http';
//import { RouterModule } from '@angular/router';
//import { FormsModule } from '@angular/forms';
//import { CommonModule } from '@angular/common';
//import { routing } from './admin.routing';
//import { AdminComponent } from './admin.component';
//import { AdminLeftsideComponent } from './layouts/admin-leftside/admin-leftside.component';
//import { AdminHeaderComponent } from './layouts/admin-header/admin-header.component';
//@NgModule({
//    imports: [routing, FormsModule, ReactiveFormsModule, HttpModule,RouterModule],
//    declarations: [AdminComponent, AdminLeftsideComponent, AdminHeaderComponent],
//    providers:[]
//})

//export class AdminModule { }