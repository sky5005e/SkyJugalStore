//import { Routes, RouterModule } from '@angular/router';
//import { ModuleWithProviders } from '@angular/core';
//import { AdminComponent } from './admin.component';
//import { AuthenticationService } from '../_services/index';

//export const routes: Routes = [
//    {
//        path: '',
//        component: AdminComponent,
//        //canActivate: [AuthenticationService],
//        children: [

//            {
//                path: 'agents',               
//                loadChildren:'./agents/agents.module#ContactModule'
//            }
//        //{
//        //    path:"SupportContract",
//        //    loadChildren:'./supportcontract/supportcontract.module#SupportContractModule'
//        //},

//        ]
//    }
//];
//export const routing: ModuleWithProviders = RouterModule.forChild(routes);