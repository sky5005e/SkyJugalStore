import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-leftside',
  templateUrl: './admin-leftside.component.html',
})
export class AdminLeftsideComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
