﻿import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-admin-header',
    templateUrl: '/app/_directives/header.component.html'
})
export class AdminHeaderComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }
}
