﻿import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-logout',
    templateUrl: '/app/_directives/logout.component.html'
})
export class LogoutComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }
}
