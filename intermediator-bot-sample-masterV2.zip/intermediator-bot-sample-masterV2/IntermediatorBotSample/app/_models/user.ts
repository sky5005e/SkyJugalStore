﻿export class User {
    id: number;
    username: string;
    password: string;
    firstName: string;
    lastName: string;
    confirmPassword: string;
    address : string;
    city : string;
    state : string;
    postalCode : string;

}