﻿import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'app',
    templateUrl: '/app/app.component.html'
})

export class AppComponent { }