﻿import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/index';
import { LoginComponent } from './login/index';
import { RegisterComponent } from './register/index';
import { UsersComponent } from './user/index';
import { ForgotPasswordComponent } from './forgotpassword/index';
import { AuthGuard } from './_guards/auth.guard';
import { AdminComponent } from './admin/index';
import { AgentComponent } from './admin/index';
import { HistoryComponent } from './admin/index';
const appRoutes: Routes = [
    { path: '', component: HomeComponent, canActivate: [AuthGuard] },
    { path: 'login', component: LoginComponent },
    { path: 'register', component: RegisterComponent },
    { path: 'user', component: UsersComponent },
    { path: 'forgotpassword', component: ForgotPasswordComponent },
    { path: 'agents', component: AgentComponent, canActivate: [AuthGuard]  },
    { path: 'history', component: HistoryComponent },
    //{ path: 'admin', loadChildren: './admin/admin.module#AdminModule' },
   // { path: 'User', loadChildren: './user/user.module#UserModule' }
    // otherwise redirect to home
    { path: '**', redirectTo: '' }


];

export const routing = RouterModule.forRoot(appRoutes);