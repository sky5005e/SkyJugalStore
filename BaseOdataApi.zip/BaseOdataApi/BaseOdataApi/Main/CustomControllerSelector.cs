﻿using Intrepid.ServiceBus.API.Controllers;
using Intrepid.ServiceBus.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Http.Controllers;
using System.Web.Http.Dispatcher;
using System.Web.OData.Builder;

namespace Intrepid.ServiceBus.API
{
    public class CustomControllerSelector : IHttpControllerSelector
    {
        private IDictionary<string, HttpControllerDescriptor> _controllerMappings;

        public CustomControllerSelector(HttpConfiguration configuration, IEnumerable<EntitySetConfiguration> entitySets)
        {
            _controllerMappings = GenerateMappings(configuration, entitySets);
        }

        private IDictionary<string, HttpControllerDescriptor> GenerateMappings(HttpConfiguration config, IEnumerable<EntitySetConfiguration> entitySets)
        {
            IDictionary<string, HttpControllerDescriptor> dictionary = new Dictionary<string, HttpControllerDescriptor>();

            // Map root controller
            dictionary.Add("Home", new HttpControllerDescriptor(config, "Home", typeof(HomeController)));
            dictionary.Add("Account", new HttpControllerDescriptor(config, "Account", typeof(AccountController)));

            foreach (EntitySetConfiguration set in entitySets)
            {

                var genericControllerDescription = new HttpControllerDescriptor(config, set.Name, typeof(HicomApiController<>).MakeGenericType(set.ClrType));
                dictionary.Add(set.Name, genericControllerDescription);
            }

            return dictionary;
        }

        public HttpControllerDescriptor SelectController(HttpRequestMessage request)
        {
            var path = request.RequestUri.LocalPath.Split('/', '(');
            if (!String.IsNullOrEmpty(path[1]))
                return _controllerMappings[path[1]];
            else
                return null;
        }

        public IDictionary<string, HttpControllerDescriptor> GetControllerMapping()
        {
            return _controllerMappings;
        }
    }
}