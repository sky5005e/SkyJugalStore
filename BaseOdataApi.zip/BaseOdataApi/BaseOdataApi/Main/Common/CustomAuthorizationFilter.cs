﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using System.Web.Mvc;
using System.Web.OData.Extensions;

namespace Intrepid.ServiceBus.API
{

    public class CustomAuthorizationFilter : System.Web.Http.Filters.IAuthorizationFilter
    {
        public bool AllowMultiple { get { return false; } }
       
        public Task<HttpResponseMessage> ExecuteAuthorizationFilterAsync(HttpActionContext actionContext, CancellationToken cancellationToken, Func<Task<HttpResponseMessage>> continuation)
        {
            // check the auth
            var request = actionContext.Request;
            string authHeader = actionContext.Request.Headers.Authorization.ToString();
            var odataPath = request.ODataProperties().Path;
            if (odataPath != null )// && odataPath.NavigationSource != null && odataPath.NavigationSource.Name == "Patients")
            {
                Hicom.Core.Client.Security.SecurityUser user; // = new Hicom.Core.Client.Security.SecurityUser();
               
                if (TryGetPrincipal(authHeader, out user))
                {
                   // HttpContext.Current.User = user;

                }
                if (user.HasError)
                {
                    //var msg = new HttpResponseMessage(HttpStatusCode.Unauthorized) { ReasonPhrase =  "Whoops!!!" };
                    request.CreateErrorResponse(HttpStatusCode.Unauthorized, "Whoops!!!");
                   // throw new HttpResponseException(msg);

                    var response = new HttpResponseMessage(HttpStatusCode.Unauthorized);
                    return Task.FromResult(response);
                }
                else
                {
                    return continuation();
                    //var response = new HttpResponseMessage(HttpStatusCode.BadRequest);
                    //return Task.FromResult(response);
                }
                
            }

            else
                return continuation();
        }
    
        private bool TryGetPrincipal(string authHeader, out Hicom.Core.Client.Security.SecurityUser user)
        {
            var creds = ParseAuthHeader(authHeader);
            if (creds != null)
            {
                if (TryGetPrincipal(creds[0], creds[1], out user)) return true;
            }

            user = null;
            return false;
        }

        private string[] ParseAuthHeader(string authHeader)
        {
            // Check this is a Basic Auth header
            if (authHeader == null || authHeader.Length == 0 || !authHeader.StartsWith("Basic")) return null;

            // Pull out the Credentials with are seperated by ':' and Base64 encoded
            string base64Credentials = authHeader.Substring(6);
            string[] credentials = Encoding.ASCII.GetString(Convert.FromBase64String(base64Credentials)).Split(new char[] { ':' });

            if (credentials.Length != 2 || string.IsNullOrEmpty(credentials[0]) || string.IsNullOrEmpty(credentials[0])) return null;

            // Okay this is the credentials
            return credentials;
        }

        private bool TryGetPrincipal(string userName, string password, out Hicom.Core.Client.Security.SecurityUser user)
        {
            var status = Hicom.Core.Client.Security.SecurityUserManager.LoginResult.Success;

           // Hicom.Core.Client.Security.SecurityUserManager.ChangePassword(userName, password);

            user = Hicom.Core.Client.Security.SecurityUserManager.ValidateUser(userName, password, ref status, null);
            return true;
        }
    }
   
    public class HttpCustomBasicUnauthorizedResult : HttpUnauthorizedResult
    {
        // the base class already assigns the 401.
        // we bring these constructors with us to allow setting status text
        public HttpCustomBasicUnauthorizedResult() : base() { }
        public HttpCustomBasicUnauthorizedResult(string statusDescription) : base(statusDescription) { }

        public override void ExecuteResult(ControllerContext context)
        {
            if (context == null) throw new ArgumentNullException("context");

            // this is really the key to bringing up the basic authentication login prompt.
            // this header is what tells the client we need basic authentication
            context.HttpContext.Response.AddHeader("WWW-Authenticate", "Basic");
            base.ExecuteResult(context);
        }
    }
}