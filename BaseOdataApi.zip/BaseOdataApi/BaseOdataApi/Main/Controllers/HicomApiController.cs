﻿using Intrepid.ServiceBus.API.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.OData;
using System.Web.OData.Routing;
using System.Collections.Generic;
using Intrepid.ServiceBus.Data;
using System.Data.Objects.DataClasses;

namespace Intrepid.ServiceBus.API.Controllers
{
    
    public class HicomApiController<TEntity> : ODataController where TEntity : EntityObject
    {
       
        #region Properties.
        private GenericRepository<TEntity> _GenericRepository;
        private IntrepidServiceBusEntities _Context = new IntrepidServiceBusEntities();
        #endregion
        public HicomApiController()
        {
            _GenericRepository = new GenericRepository<TEntity>(_Context);
        }
       

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                this._Context.Dispose();
            }
            base.Dispose(disposing);
        }

        #region CRUD

        // E.g. GET http://localhost/TEntity
        [EnableQuery] // EnableQuery allows filter, sort, page, top, etc.
        public virtual IEnumerable<TEntity> Get()
        {
            return _GenericRepository.Get();
        }
        
        // E.g. GET http://localhost/TEntity(1)
        [EnableQuery]
        public virtual IHttpActionResult Get([FromODataUri] long key)
        {
            var obj = _GenericRepository.GetByID(key);
            if (obj == null)
            {
                return NotFound();
            }

            return Ok(obj);
        }

        // E.g. POST http://localhost/TEntity
        public virtual async Task<IHttpActionResult> Post(TEntity obj)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _GenericRepository.Insert(obj);
            await _Context.SaveChangesAsync();
         
            return Created(obj);
        }

        // E.g. PATCH http://localhost/TEntity(1)
        public virtual async Task<IHttpActionResult> Patch([FromODataUri] long key, Delta<TEntity> delta)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            
            var entity = _GenericRepository.GetByID(key);
            if (entity == null)
            {
                return NotFound();
            }

            delta.Patch(entity);

            try
            {
                await _Context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {

                throw;

            }

            return Updated(entity);
        }

        // E.g. PUT http://localhost/TEntity(1)
        public virtual async Task<IHttpActionResult> Put([FromODataUri] long key, TEntity obj)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }


            _Context.Entry(obj).State = EntityState.Modified;

            try
            {
                await _Context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {

                throw;

            }

            return Updated(obj);
        }

        // E.g. DELETE http://localhost/TEntity(1)
        public virtual async Task<IHttpActionResult> Delete([FromODataUri] long key)
        {
            _GenericRepository.Delete(key);
            await _Context.SaveChanges();
            return StatusCode(HttpStatusCode.NoContent);
        }
        
        #endregion
    }
}