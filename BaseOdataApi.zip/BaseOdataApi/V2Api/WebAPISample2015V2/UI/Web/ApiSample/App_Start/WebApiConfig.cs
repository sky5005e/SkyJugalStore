﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web.Http;
using Microsoft.Owin.Security.OAuth;
using Newtonsoft.Json.Serialization;
using System.ComponentModel;
using WebAPI.Business;
using ApiSample.Models;
using WebAPI.Data;
using System.Web.Http.OData.Builder;
using System.Web.OData.Extensions;
using System.Web.Http.OData.Extensions;

namespace ApiSample
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {

           

            ODataConventionModelBuilder builder = new ODataConventionModelBuilder();
            builder.EntitySet<WebAPI.Data.Patient>("HicomOdata");
            builder.EntitySet<Episode>("Episodes");
            builder.EntitySet<EpisodeCareItem>("EpisodeCareItems");
            builder.EntitySet<EpisodeDiagnosi>("EpisodeDiagnosis");
            builder.EntitySet<PatientAddress>("PatientAddresses");
            builder.EntitySet<PatientAlert>("PatientAlerts");
            builder.EntitySet<PatientContact>("PatientContacts");
            config.Routes.MapODataServiceRoute("odata", "odata", builder.GetEdmModel());


            // Web API configuration and services
            // Configure Web API to use only bearer token authentication.
            //config.SuppressDefaultHostAuthentication();
            //config.Filters.Add(new HostAuthenticationFilter(OAuthDefaults.AuthenticationType));

            //// Web API routes
            //config.MapHttpAttributeRoutes();

            //config.Routes.MapHttpRoute(
            //    name: "DefaultApi",
            //    routeTemplate: "api/{controller}/{action}/{id}",
            //    defaults: new { id = RouteParameter.Optional }
            //);

            // Specify the MediaTypeFormatter from url
            // TypeDescriptor.AddAttributes(typeof(Patient), new TypeConverterAttribute(typeof(PatientConverter)));
        }
    }
}
