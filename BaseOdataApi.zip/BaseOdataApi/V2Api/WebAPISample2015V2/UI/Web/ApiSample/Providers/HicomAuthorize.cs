﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ApiSample
{
    /// <summary>
    /// Hicom authorize.
    /// </summary>
    public class HicomAuthorize : ActionFilterAttribute
    {
        #region Properties

        /// <summary>
        /// Gets or sets the security object.
        /// </summary>
        /// <value>
        /// The security object.
        /// </value>
        public string SecurityObject { get; set; }



        #endregion

        #region Methods

        /// <summary>
        /// Executes the action executing action.
        /// </summary>
        /// <param name="filterContext">Context for the filter.</param>
        /// <exception cref="System.InvalidOperationException">You do not have permission to view this page</exception>
        /// <exception cref="InvalidOperationException">Thrown when the requested operation is invalid.</exception>
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            //If we have role then validate the user against the role, else redirect to previous page
            if (!System.Web.HttpContext.Current.User.Identity.IsAuthenticated || Hicom.Core.Client.Security.SecurityUserManager.CurrentUser.Username == null)
            {
                if (filterContext.HttpContext.Request.IsAjaxRequest())
                    filterContext.Controller.TempData.Add("PartialViewReq", true);
                RedirectToUnauthorisedAccess(ref filterContext);
                return;
            }



            
        }

        /// <summary>
        /// Redirects to unauthorized access.
        /// </summary>
        /// <param name="filterContext">The filter context.</param>
        private void RedirectToUnauthorisedAccess(ref ActionExecutingContext filterContext)
        {
            string UserName = string.Empty; int SecurityUserId = 0;
            if (Hicom.Core.Client.Security.SecurityUserManager.CurrentUser.Username != null)
            {
                UserName = Hicom.Core.Client.Security.SecurityUserManager.CurrentUser.Username;
                SecurityUserId = Hicom.Core.Client.Security.SecurityUserManager.CurrentUser.SecurityUserId;
                string url = string.Empty;
                if (filterContext.HttpContext != null) url = filterContext.HttpContext.Request.Url.AbsoluteUri; if (string.IsNullOrEmpty(url)) url = ""; else url = " for URL= " + url;

                filterContext.HttpContext.Session["UnauthorisedAccess"] = "You do not have permission to view this page";
            }
         
        }

        #endregion
    }

}