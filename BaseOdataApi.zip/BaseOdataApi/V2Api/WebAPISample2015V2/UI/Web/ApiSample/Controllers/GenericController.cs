﻿using ApiSample.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.OData;
using System.Web.OData.Routing;

namespace ApiSample.Controllers
{
    public class GenericController<TEntity> : ODataController where TEntity : class, IndexedModel
    {
        private WebAPI.Data.WebAPIEntities db = new  WebAPI.Data.WebAPIEntities();

        private bool Exists(long key)
        {
            return GetTEntity().Any(p => p.Id == key);
        }

        private DbSet<TEntity> GetTEntity()
        {
            return db.Set<TEntity>();
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }

        #region CRUD

        // E.g. GET http://localhost/TEntity
        [EnableQuery] // EnableQuery allows filter, sort, page, top, etc.
        public IQueryable<TEntity> Get()
        {
            return GetTEntity();
        }

        // E.g. GET http://localhost/TEntity(1)
        [EnableQuery]
        public SingleResult<TEntity> Get([FromODataUri] long key)
        {
            IQueryable<TEntity> result = Get().Where(p => p.Id == key);
            return SingleResult.Create(result);
        }

        // E.g. POST http://localhost/TEntity
        public async Task<IHttpActionResult> Post(TEntity obj)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            GetTEntity().Add(obj);
            await db.SaveChangesAsync();
            return Created(obj);
        }

        // E.g. PATCH http://localhost/TEntity(1)
        public async Task<IHttpActionResult> Patch([FromODataUri] long key, Delta<TEntity> delta)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var entity = await GetTEntity().FindAsync(key);
            if (entity == null)
            {
                return NotFound();
            }

            delta.Patch(entity);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Exists(key))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Updated(entity);
        }

        // E.g. PUT http://localhost/TEntity(1)
        public async Task<IHttpActionResult> Put([FromODataUri] long key, TEntity obj)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (key != obj.Id)
            {
                return BadRequest();
            }

            db.Entry(obj).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Exists(key))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Updated(obj);
        }

        // E.g. DELETE http://localhost/TEntity(1)
        public async Task<IHttpActionResult> Delete([FromODataUri] long key)
        {
            var entity = await GetTEntity().FindAsync(key);
            if (entity == null)
            {
                return NotFound();
            }

            GetTEntity().Remove(entity);
            await db.SaveChangesAsync();
            return StatusCode(HttpStatusCode.NoContent);
        }

        #endregion
    }
}
 