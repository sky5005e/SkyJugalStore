﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using System.Web.Http.OData.Routing;
using WebAPI.Data;

namespace ApiSample.Controllers
{
    /*
    The WebApiConfig class may require additional changes to add a route for this controller. Merge these statements into the Register method of the WebApiConfig class as applicable. Note that OData URLs are case sensitive.

    using System.Web.Http.OData.Builder;
    using System.Web.Http.OData.Extensions;
    using WebAPI.Data;
    ODataConventionModelBuilder builder = new ODataConventionModelBuilder();
    builder.EntitySet<Patient>("HicomOdata");
    builder.EntitySet<Episode>("Episodes"); 
    builder.EntitySet<EpisodeCareItem>("EpisodeCareItems"); 
    builder.EntitySet<EpisodeDiagnosi>("EpisodeDiagnosis"); 
    builder.EntitySet<PatientAddress>("PatientAddresses"); 
    builder.EntitySet<PatientAlert>("PatientAlerts"); 
    builder.EntitySet<PatientContact>("PatientContacts"); 
    config.Routes.MapODataServiceRoute("odata", "odata", builder.GetEdmModel());
    */
    public class HicomOdataController : ODataController
    {
        private WebAPIEntities db = new WebAPIEntities();

        // GET: odata/HicomOdata
        [EnableQuery]
        public IQueryable<Patient> GetHicomOdata()
        {
            return db.Patients;
        }

        // GET: odata/HicomOdata(5)
        [EnableQuery]
        public SingleResult<Patient> GetPatient([FromODataUri] int key)
        {
            return SingleResult.Create(db.Patients.Where(patient => patient.PatientId == key));
        }

        // PUT: odata/HicomOdata(5)
        public async Task<IHttpActionResult> Put([FromODataUri] int key, Delta<Patient> patch)
        {
            Validate(patch.GetEntity());

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            Patient patient = await db.Patients.FindAsync(key);
            if (patient == null)
            {
                return NotFound();
            }

            patch.Put(patient);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PatientExists(key))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Updated(patient);
        }

        // POST: odata/HicomOdata
        public async Task<IHttpActionResult> Post(Patient patient)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Patients.Add(patient);
            await db.SaveChangesAsync();

            return Created(patient);
        }

        // PATCH: odata/HicomOdata(5)
        [AcceptVerbs("PATCH", "MERGE")]
        public async Task<IHttpActionResult> Patch([FromODataUri] int key, Delta<Patient> patch)
        {
            Validate(patch.GetEntity());

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            Patient patient = await db.Patients.FindAsync(key);
            if (patient == null)
            {
                return NotFound();
            }

            patch.Patch(patient);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PatientExists(key))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Updated(patient);
        }

        // DELETE: odata/HicomOdata(5)
        public async Task<IHttpActionResult> Delete([FromODataUri] int key)
        {
            Patient patient = await db.Patients.FindAsync(key);
            if (patient == null)
            {
                return NotFound();
            }

            db.Patients.Remove(patient);
            await db.SaveChangesAsync();

            return StatusCode(HttpStatusCode.NoContent);
        }

        // GET: odata/HicomOdata(5)/Episodes
        [EnableQuery]
        public IQueryable<Episode> GetEpisodes([FromODataUri] int key)
        {
            return db.Patients.Where(m => m.PatientId == key).SelectMany(m => m.Episodes);
        }

        // GET: odata/HicomOdata(5)/EpisodeCareItems
        [EnableQuery]
        public IQueryable<EpisodeCareItem> GetEpisodeCareItems([FromODataUri] int key)
        {
            return db.Patients.Where(m => m.PatientId == key).SelectMany(m => m.EpisodeCareItems);
        }

        // GET: odata/HicomOdata(5)/EpisodeDiagnosis
        [EnableQuery]
        public IQueryable<EpisodeDiagnosi> GetEpisodeDiagnosis([FromODataUri] int key)
        {
            return db.Patients.Where(m => m.PatientId == key).SelectMany(m => m.EpisodeDiagnosis);
        }

        // GET: odata/HicomOdata(5)/PatientAddresses
        [EnableQuery]
        public IQueryable<PatientAddress> GetPatientAddresses([FromODataUri] int key)
        {
            return db.Patients.Where(m => m.PatientId == key).SelectMany(m => m.PatientAddresses);
        }

        // GET: odata/HicomOdata(5)/PatientAlerts
        [EnableQuery]
        public IQueryable<PatientAlert> GetPatientAlerts([FromODataUri] int key)
        {
            return db.Patients.Where(m => m.PatientId == key).SelectMany(m => m.PatientAlerts);
        }

        // GET: odata/HicomOdata(5)/PatientContacts
        [EnableQuery]
        public IQueryable<PatientContact> GetPatientContacts([FromODataUri] int key)
        {
            return db.Patients.Where(m => m.PatientId == key).SelectMany(m => m.PatientContacts);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool PatientExists(int key)
        {
            return db.Patients.Count(e => e.PatientId == key) > 0;
        }
    }
}
