﻿using Hicom.Core.Client.Security;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebAPI.Data;
namespace ApiSample.Controllers
{

   
    public class PatientExtendController : HicomApiController<WebAPI.Data.Patient>
    {
       
    }
}
