﻿using ApiSample.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using WebAPI.Business;

namespace ApiSample.Controllers
{
    /// <summary>
    /// api/PatientModelFilter
    /// </summary>
    [RoutePrefix("PatientModelFilter")]
    public class PatientFilterModelBinderController : ApiController
    {
        #region Modal Binding
        /// <summary>
        /// Specific type of solution as compare to TypeConverter, because it uses the httpcontext 
        /// MVC supports model concept so we can use the modelbinders
        /// URL type PatientModelFilter/binder?patient=1135|Surname|FirstName|Sex|Nationality|PassportNumber
        /// </summary>
        /// <param name="patient">single parameter ?patient</param>
        /// <returns></returns>
        [Route("binder")]
        [HttpPost]
        public HttpResponseMessage ModelBinder([ModelBinder(typeof(PatientModelBinder))]Patient patient)
        {
            if (patient == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Patient is cannot be null.");
            }

            if (ModelState.IsValid)
            {
                return Request.CreateResponse(HttpStatusCode.OK, patient);
            }

            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
        }

        #endregion
    }
}
