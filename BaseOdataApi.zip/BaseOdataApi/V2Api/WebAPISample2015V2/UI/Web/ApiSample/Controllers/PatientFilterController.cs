﻿using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebAPI.Business;

namespace ApiSample.Controllers
{
    /// <summary>
    /// api/PatientFilter
    /// </summary>
    [RoutePrefix("PatientFilter")]
    public class PatientFilterController : ApiController
    {

        #region Paramters Binding
        /// <summary>
        /// Here were will get the data by passing name as a query string parameter and Patient info by form url encoded
        /// </summary>
        /// <param name="name"></param>
        /// <param name="patient"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("querystring")]
        public HttpResponseMessage PostQuery(string name, Patient patient)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Name is required.");
            }

            if (patient == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Patient is required.");
            }

            if (ModelState.IsValid)
            {
                return Request.CreateResponse(HttpStatusCode.OK, patient);
            }

            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
        }
        //[HttpGet]
        //[Route("querystring")]
        //public HttpResponseMessage PostQuery(string query)
        //{
        //    if (string.IsNullOrWhiteSpace(name))
        //    {
        //        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Name is required.");
        //    }
            
        //    if (ModelState.IsValid)
        //    {
        //        return Request.CreateResponse(HttpStatusCode.OK, patient);
        //    }

        //    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
        //}
        /// <summary>
        /// Here were will get the data by passing Patient info by form url encoded and /name=value
        /// </summary>
        /// <param name="name"> /name=value </param>
        /// <param name="patient"> Patient info from form url encoded </param>
        /// <returns></returns>
        [HttpPost]
        [Route("standard/{name}")]
        public HttpResponseMessage Post(string name, Patient patient)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Name is required.");
            }


            if (patient == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Patient is required.");
            }

            if (ModelState.IsValid)
            {
                return Request.CreateResponse(HttpStatusCode.OK, patient);
            }

            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
        }
        /// <summary>
        /// Retrieve data 
        /// to run this method please remove this line    TypeDescriptor.AddAttributes(typeof(Patient), new TypeConverterAttribute(typeof(PatientConverter))); from webApiConfig.cs file
        /// </summary>
        /// <param name="name"> from form raw data "value"</param>
        /// <param name="patient">use query string to pass patient properties</param>
        /// <returns></returns>
        [HttpPost]
        [Route("data")]
        public HttpResponseMessage PostIt([FromBody]string name, [FromUri]Patient patient)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Name is required.");
            }
            if (patient == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Patient is required.");
            }

            if (ModelState.IsValid)
            {
                return Request.CreateResponse(HttpStatusCode.OK, patient);
            }

            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
        }

        #endregion Parameters Binding

        #region TypeConvertors
        /// <summary>
        /// Here we will use pipe for passing the parameters and it will refer the type of class under {patient} on route attribute, {patient} should be same as we used in our arguments
        /// We have created a PatientConverter class for it.
        /// Also specifiied our type converter attribute to WebApiConfig.cs file
        /// </summary>
        /// <param name="patient">eg : 1135|Yadav|Surendar|Male|Indian|TO01244</param>
        /// <returns></returns>
        [Route("{patient}")]
        [HttpGet]
        public HttpResponseMessage VectorFromUri(Patient patient)
        {
            if (patient == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Patient is cannot be null.");
            }

            if (ModelState.IsValid)
            {
                return Request.CreateResponse(HttpStatusCode.OK, patient);
            }

            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
        }

        #endregion

       

    }
}
