﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;


using WebAPI.Business;

namespace ApiSample.Controllers
{
    [Authorize]
    [RoutePrefix("Patient")]
    public class PatientController : ApiController
    {
        private readonly WebAPI.Data.UnitOfWork _unitOfWork;
        #region Public Constructor

        /// <summary>
        /// Public constructor to initialize patient service instance
        /// </summary>
        public PatientController()
        {
            _unitOfWork = new WebAPI.Data.UnitOfWork();
        }

        #endregion

        // GET api/patient
        [Route("allpatients")]
        [Route("all")]
        public HttpResponseMessage Get()
        {
            var patients = _unitOfWork.PatientRepository.GetAll().Select(q => new Patient { PatientId = q.PatientId, FirstName = q.FirstName, Surname = q.Surname, Nationality = q.Nationality }).ToList(); ;

            if (patients.Any())
                return Request.CreateResponse(HttpStatusCode.OK, patients);

            return Request.CreateErrorResponse(HttpStatusCode.NotFound, "patients not found");
        }

        // GET api/patient
        [Route("findpatient")]
        public HttpResponseMessage Get(string Surname, string FirstName, string Nationality)
        {
            var patients = _unitOfWork.PatientRepository.GetManyQueryable(p => (string.IsNullOrEmpty(Surname) || p.Surname.ToLower() == Surname.ToLower()) && (string.IsNullOrEmpty(FirstName) || p.FirstName.ToLower() == FirstName.ToLower()) && (string.IsNullOrEmpty(Nationality) || p.Nationality.ToLower() == Nationality.ToLower())).Select(q => new Patient { PatientId = q.PatientId, FirstName = q.FirstName, Surname = q.Surname, Nationality = q.Nationality }).ToList();
            if (patients.Any())
                return Request.CreateResponse(HttpStatusCode.OK, patients);

            return Request.CreateErrorResponse(HttpStatusCode.NotFound, "patients not found");
        }

        // GET api/patient/5
        public HttpResponseMessage Get(int id)
        {
            var _patient = _unitOfWork.PatientRepository.GetByID(id);
            if (_patient != null)
            {
                Patient patient = new Patient
                {
                    PatientId = _patient.PatientId,
                    FirstName = _patient.FirstName,
                    Surname = _patient.Surname,
                    Nationality = _patient.Nationality
                };

                return Request.CreateResponse(HttpStatusCode.OK, patient);
            }
            return Request.CreateErrorResponse(HttpStatusCode.NotFound, "No patient found for this id");
        }

        // POST api/patient
        public Patient Post([FromBody] Patient patientEntity)
        {
            WebAPI.Data.Patient patient = new WebAPI.Data.Patient();
            //patient.PatientId = patientEntity.PatientId;
            patient.FirstName = patientEntity.FirstName;
            patient.Surname = patientEntity.Surname;
            patient.Nationality = patientEntity.Nationality;

            _unitOfWork.PatientRepository.Insert(patient);
            _unitOfWork.Save();
            // return patients with id
            patientEntity.PatientId = patient.PatientId;

            return patientEntity;
        }

        // PUT api/patient/5
        public bool Put([FromBody]Patient patientEntity)
        {
            var success = false;

            var _patient = _unitOfWork.PatientRepository.GetByID(patientEntity.PatientId);
            if (_patient != null)
            {
                _patient.FirstName = patientEntity.FirstName;
                _patient.Surname = patientEntity.Surname;
                _patient.Nationality = patientEntity.Nationality;

                _unitOfWork.PatientRepository.Update(_patient);
                _unitOfWork.Save();
                success = true;
            }

            return success;
        }

        // DELETE api/patient/5
        public bool Delete(int id)
        {
            var success = false;
            if (id > 0)
            {
                var patient = _unitOfWork.PatientRepository.GetByID(id);
                if (patient != null)
                {

                    _unitOfWork.PatientRepository.Delete(patient);
                    _unitOfWork.Save();
                    success = true;
                }         
               
            }
            return success;
        }
    }
}
