﻿using System.Web.Http.Controllers;
using System.Web.Http.ModelBinding;
using WebAPI.Business;

namespace ApiSample.Models
{
   
    public class PatientModelBinder : IModelBinder
    {
        public bool BindModel(HttpActionContext actionContext, ModelBindingContext bindingContext)
        {
            Patient patient;

            if (bindingContext.ModelType != typeof(Patient))
            {
                return false;
            }

            var value = bindingContext.ValueProvider.GetValue(bindingContext.ModelName);

            if (value == null)
            {
                return false;
            }

            var text = value.RawValue as string;

            if (Patient.TryParse(text, out patient))
            {
                bindingContext.Model = patient;
                return true;
            }

            bindingContext.ModelState.AddModelError(bindingContext.ModelName, "Cannot convert value to vector.");
            return false;
        }
    }
}