﻿using System;
using System.ComponentModel;

using WebAPI.Business;

namespace ApiSample.Models
{
    
    [TypeConverter(typeof(Patient))]
    public class PatientConverter : TypeConverter
    {
        public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
        {
            return false;
        }

        public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
        {
            return sourceType == typeof(string) || base.CanConvertFrom(context, sourceType);
        }

        public override object ConvertFrom(ITypeDescriptorContext context, System.Globalization.CultureInfo culture, object value)
        {
            var source = value as string;
            Patient patient;

            return Patient.TryParse(source, out patient) ? patient :
                base.ConvertFrom(context, culture, value);
        }
    }
}