﻿app.controller('patientCtrl', function ($scope, $http, patientService) {
    $scope.token = '';
   // $http.defaults.headers.common.Authorization = 'Bearer ' + $scope.token;

    $scope.patientData = null;
    $scope.loginData = {
        username: "",
        password: ""
    };
    //Add new record
    $scope.getdata = function () {
        $http.get('api/patientextend/get', {headers: { 'Authorization': 'Bearer ' + $scope.token },
        }).then(function (d) {
            $scope.patientData = d.data;
            $("#main_div").show();
        }, function (response) {
            $("#main_div").hide();
            //alert('error occurred' + response.data.ExceptionMesage);
            $("#result").text(response.statusText);
        });
    };

    $scope.patient = {
        PatientId: '',
        FirstName: '',
        Surname: '',
        Nationality: ''
    };

    $scope.clear = function () {
        $scope.patient.PatientId = '',
        $scope.patient.FirstName = '',
        $scope.patient.Surname = '',
        $scope.patient.Nationality = '',
       
        $scope.addnewdiv = false;
        $scope.updatediv = false;
    };

    //Add new record
    $scope.save = function () {
        if ($scope.patient.FirstName != '' && $scope.patient.Surname != '' && $scope.patient.Nationality != '') {
            $http({
                method: 'POST',
                url: 'api/patient',
                data: $scope.patient,
                headers: { 'Authorization': 'Bearer ' + $scope.token }
            }).then(function successCallback(response) {
                $scope.patientData.push(response.data);
                $scope.clear();
                alert('Inserted successfully!!');
                $scope.addnewdiv = false;
            }, function errorCallback(response) {
                alert('error:' + response.data.ExceptionMesage);
            });
        }
        else {
           
            alert('Please enter all the values!!');
        }
    };

    //Edit records
    $scope.edit = function (data) {
        $scope.patient = { PatientId: data.PatientId, FirstName: data.FirstName, Surname: data.Surname, Nationality: data.Nationality }
        $scope.updatediv = true;
    };


   //Cancel record
    $scope.cancel = function () {
        $scope.clear();
    };

    //Update record
    $scope.update = function () {
        if ($scope.patient.FirstName != '' && $scope.patient.Surname != '' && $scope.patient.Nationality != '') {
            $http({
                method: 'PUT',
                url: 'api/patient',
                data: $scope.patient,
                headers: { 'Authorization': 'Bearer ' + $scope.token }
            }).then(function successCallback(response) {
                $scope.patientData = response.data;
                $scope.clear();
                alert('Updated successfully!!');
                $scope.updatediv = false;
            }, function errorCallback(response) {
               alert('error:' + response.data.ExceptionMesage);
            });
        }
        else {
            alert('Please enter all the values!!');
        }
    };

    //Delete record
    $scope.delete = function (index) {
        $http({
            method: 'DELETE',
            url: 'api/patient/' + $scope.patientData[index].PatientId,
            headers: { 'Authorization': 'Bearer ' + $scope.token }
        }).then(function successCallback(response) {
            $scope.patientData.splice(index, 1);
            alert('Record deleted successfully');
        }, function failureCallback(response) {
            alert('error:' + response.data.ExceptionMesage)
        });

    };

    $scope.login = function () {
        $('#btnLogin').attr("disabled", "");
        var data = "grant_type=password&username=" + $scope.loginData.username + "&password=" + $scope.loginData.password;
        $http.post('/token', data).success(function (response) {
            $scope.token = response.access_token;
            $('#login').hide('slide');
        }, function failureCallback(response) {
            $("#errorInfo").text("The username or password is invalid.");
            $("#btnLogin").removeAttr("disabled");
        });
    };
});

