﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using WebAPISample.Business;

namespace WebAPI.Business
{
    public class Patient : HicomBase
    {
        [Key]
        public int PatientId { get; set; }
        [Required]
        public string Surname { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string Sex { get; set; }
        [Required]
        public string Nationality { get; set; }
        [Required]
        public string PassportNumber { get; set; }
        [Required]
        public string EmailAddress { get; set; }

      
        public decimal Height { get; set; }
        public decimal Weight { get; set; }

        [ValidateBMI(ErrorMessage = "Invalid BMI data. Please check all the fields.")]
        public decimal BMI { get; set; }

        public static bool TryParse(string text, out Patient patient)
        {
            patient = null;

            if (string.IsNullOrWhiteSpace(text))
            {
                return false;
            }

            var properties = text.Split('|');// we can use any separator
            // check if for length of array string passed
            //if (properties.Length != 7)
            //{
            //    return false;
            //}


            patient = new Patient();
            patient.PatientId = Convert.ToInt32(properties[0]);
            patient.Surname = properties[1];
            patient.FirstName = properties[2];
            patient.Sex = properties[3];
            patient.Nationality = properties[4];
            patient.PassportNumber = properties[5];
           


            return true;
        }
    }
}
