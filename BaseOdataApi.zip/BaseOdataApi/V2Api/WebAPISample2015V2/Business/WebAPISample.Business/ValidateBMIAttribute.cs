﻿using System;
using System.Globalization;
using System.ComponentModel.DataAnnotations;
using System.Reflection;


namespace WebAPI.Business
{
   
    public class ValidateBMIAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            bool flag = false;
            string msg = string.Empty;
            object instance = validationContext.ObjectInstance;
            Type type = instance.GetType();
            PropertyInfo property = type.GetProperty("BMI");
            PropertyInfo propWeight = type.GetProperty("Weight");
            PropertyInfo propHeight = type.GetProperty("Height");

            decimal propertyBMIValue = (decimal)property.GetValue(instance);
            decimal propertyHeightValue = (decimal)propHeight.GetValue(instance);
            decimal propertyWeightValue = (decimal)propWeight.GetValue(instance);

            //if (propertyBMIValue <= 0)
            //{
            //    msg = "BMI is required";
            //    flag = false;
            //}
            if (propertyHeightValue <= 0 && propertyWeightValue <= 0)
            {
                msg = "Height and Weight are required for BMI";
                flag = false;
            }
            else if (propertyHeightValue >= 0 && propertyWeightValue <= 0)
            {
                msg = "Weight is required for BMI";
                flag = false;
            }
            else if (propertyHeightValue <= 0 && propertyWeightValue >= 0)
            {
                msg = "Height is required BMI";
                flag = false;
            }


            if (!flag)
            {
                ValidationResult result = new ValidationResult(msg);
                return result;
            }
            else
            {
                return null;
            }
        }
    }
}
