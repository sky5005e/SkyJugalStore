﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebAPI.Data;

namespace WebAPI.Service
{
    public interface IPatientService
    {
        Patient GetPatientById(int patientId);
        IEnumerable<Patient> GetAllPatients();
        int AddPatient(Patient patient);
        bool SavePatient(int patientId, Patient patientEntity);
        bool DeletePatient(int patientId);
    }
}
