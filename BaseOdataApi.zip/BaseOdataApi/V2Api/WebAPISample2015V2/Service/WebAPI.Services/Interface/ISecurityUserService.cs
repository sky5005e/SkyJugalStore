﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebAPI.Data;

namespace WebAPI.Service
{
    public interface ISecurityUserService
    {
        int Authenticate(string userName, string password);
        SecurityUser GetUser(string UserName);
    }
}
