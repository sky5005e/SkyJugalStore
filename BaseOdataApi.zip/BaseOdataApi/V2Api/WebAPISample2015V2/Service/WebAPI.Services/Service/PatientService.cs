﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Transactions;
using System.Threading.Tasks;
using WebAPI.Data;

namespace WebAPI.Service
{
    public class PatientService : IPatientService
    {

        private readonly UnitOfWork _unitOfWork;

        /// <summary>
        /// Public constructor.
        /// </summary>
        public PatientService()
        {
            _unitOfWork = new UnitOfWork();
        }

        public Patient GetPatientById(int patientId)
        {
            return _unitOfWork.PatientRepository.GetByID(patientId);
           
        }

        public IEnumerable<Patient> GetAllPatients()
        {
            return _unitOfWork.PatientRepository.GetAll().ToList();

        }

        public int AddPatient(Patient patient)
        {
            using (var scope = new TransactionScope())
            {

                _unitOfWork.PatientRepository.Insert(patient);
                _unitOfWork.Save();
                scope.Complete();
                return patient.PatientId;
            }
        }

        public bool SavePatient(int patientId, Patient patientEntity)
        {
            var success = false;
            if (patientEntity != null)
            {
                using (var scope = new TransactionScope())
                {
                    var _patient = _unitOfWork.PatientRepository.GetByID(patientId);
                    if (_patient != null)
                    {
                        _unitOfWork.PatientRepository.Update(_patient);
                        _unitOfWork.Save();
                        scope.Complete();
                        success = true;
                    }
                }
            }
            return success;
        }

        public bool DeletePatient(int patientId)
        {
            var success = false;
            if (patientId > 0)
            {
                using (var scope = new TransactionScope())
                {
                    var patient = _unitOfWork.PatientRepository.GetByID(patientId);
                    if (patient != null)
                    {

                        _unitOfWork.PatientRepository.Delete(patient);
                        _unitOfWork.Save();
                        scope.Complete();
                        success = true;
                    }
                }
            }
            return success;
        }
    }
}