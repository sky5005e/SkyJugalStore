﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebAPI.Data;

namespace WebAPI.Service
{
    public class SecurityUserService : ISecurityUserService
    {
        private readonly UnitOfWork _unitOfWork;

        /// <summary>
        /// Public constructor.
        /// </summary>
        public SecurityUserService()
        {
            _unitOfWork = new UnitOfWork();
        }



        public SecurityUser GetUser(string Username)
        {
            return _unitOfWork.UserRepository.Get(q=>q.Username == Username);
        }

       
        /// <summary>
        /// Public method to authenticate user by user name and password.
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public int Authenticate(string userName, string password)
        {
            var user = _unitOfWork.UserRepository.Get(u => u.Username == userName && u.Password == password);
            if (user != null && user.SecurityUserId > 0)
            {
                return user.SecurityUserId;
            }
            return 0;
        
        }
    }
}
