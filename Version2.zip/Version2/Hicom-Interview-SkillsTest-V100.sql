--------------------------- 2.1	SELECT ------------------------------------------------------------
--Create a query to return all records and all columns from the �Patient� table
GO


--------------------------- 2.2	ORDER -------------------------------------------------------------
/*
Create a query to return the �Surname� and �Firstname� fields only from the �Patient� 
table ordered by Surname ascending then Firstname descending
*/
GO


--------------------------- 2.3	LOCK ---------------------------------------------------------------
/*
A developer is running a query on the database you are working on and is causing locks on the Patient table. 
Adapt the query above to ignore any current locks on the Patient table.
*/
GO
 

--------------------------- 2.4	WHERE & DATA MANIPULATION ------------------------------------------
/*
Create a query to return the �Surname�,�Firstname� and �Title� fields only from the �Patient� table 
Ordered by Surname descending then Firstname ascending. 
Include ONLY records that contain the word �Osborne� in the Surname. 
Output the column Title with a pseudonym of �PatientTitle�. 
If the Title field is null return a question mark.
*/



--------------------------- 2.5	JOIN ---------------------------------------------------------------
/*
Create a query to return Surname, Firstname, EpisodeDate, ArrivalTime from two tables �Patient� and �Episode�. 
Episode is a sub-table of Patient. The Patient.PatientCode field links to the Episode.PatientCode field. 
Return only those Patient records that have a corresponding Episode record.
*/
GO


--------------------------- 2.6	COUNT ---------------------------------------------------------------
/*
Create a query to return Surname, Todays Date (using a function to return the system date) and 
the count of the number of times the Surname data appears within the Patient table. Display Surname in upper case. 
Display the count of Surname with pseudonym �CountOfSurname�. Order the query by the count descending.
*/
GO

 

--------------------------- 2.7	STORED PROCEDURE-------------------------------------------------------
/*
Create a Stored Procedure entitled �_INTERVIEW_<<ApplicantSurname>>� 
Include an input parameter of @Surname defaulting to �Osborne�. The Surname field is 30 characters long. 
Return all fields within the Patient table where the Surname is equal to the value passed in the input parameter.
*/
GO

