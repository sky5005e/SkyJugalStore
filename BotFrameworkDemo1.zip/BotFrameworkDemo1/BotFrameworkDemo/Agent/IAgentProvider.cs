﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BotFrameworkDemo
{
    public interface IAgentProvider
    {
        Agent GetNextAvailableAgent();
        bool AddAgent(Agent agent);
        Agent RemoveAgent(Agent agent);
    }
}
