﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BotFrameworkDemo
{
    public static class Constants
    {
        public const string AGENT_KEY = "AgentRouteKey";
        public const string USER_KEY = "UserRouteKey";
        public const string AGENT_METADATA_KEY = "AgentMetaData";
    }
}
