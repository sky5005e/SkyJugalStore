﻿using Accent.Security.Business;
using Accent.Security.Data;
using Accent.Security.UI.Web.Core;
using Kendo.Mvc.UI;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.Mvc;
using System.Linq;

namespace Accent.Security.UI.Web.Controllers
{
    [HicomAuthorize(SecurityObject = "SecurityUser")]
    public class AuditController : Core.HicomController<Data.AuditRecord, Data.AuditQueryFilter>
    {
        #region .Methods.

        /// <summary>
        /// Gets the security user.
        /// </summary>
        /// <returns></returns>
        public JsonResult GetSecurityUser()
        {
            AuditQueryFilter filter = new AuditQueryFilter();
            filter.SecurityUserGet = GetUser();
            return Json(filter.SecurityUserGet, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Gets the user.
        /// </summary>
        /// <returns></returns>
        private List<SelectListItem> GetUser()
        {
            List<SelectListItem> user = new List<SelectListItem>();
            var userList = AuditManager.GetSecurityUser();
            foreach (var item in userList)
            {
                user.Add(new SelectListItem { Text = item.Username, Value = item.Username });
            }
            return user;
        }

        /// <summary>
        /// Indexes this instance.
        /// </summary>
        /// <returns></returns>
        [BreadCrumb(Title = "Audit")]
        public override ActionResult Index()
        {
            AuditQueryFilter filter = new AuditQueryFilter();
            return View(filter);
        }
        /// <summary>
        /// Populates the table column.
        /// </summary>
        /// <param name="TableName">Name of the table.</param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult PopulateTableColumn(string TableName = null)
        {
            try

            {
                List<AuditTableColumn_Result> list = AuditManager.AuditTableColumn(this.ReadWriteContext, TableName);
                return Json(list, JsonRequestBehavior.AllowGet);
            }
            catch (System.Exception ex)
            {
                return Json("No records" + ex.Message, JsonRequestBehavior.AllowGet);
            }
        }
        [ValidateInput(false)]
        public JsonResult IndexJson([DataSourceRequest] DataSourceRequest request, Data.AuditQueryFilter Model)
        {
            //if (!this.Permissions.ReadPermission) return Json("You do not have read permission!");
            var filter = Model;//MaintainSearchFilters(Model);
            this.ApplyFilter(ref filter, request);
            this.SearchFilter = filter;
            filter.ActivePage = request.Page;
            if (string.IsNullOrEmpty(filter.SortBy))
            {
                filter.SortBy = "AmendedDate";
                filter.SortDirection = System.ComponentModel.ListSortDirection.Descending;
            }
            filter.Items = AuditManager.ListGet(this.ReadOnlyContext, filter).OrderByDescending(x => x.AmendedDate).ToList();
            //Cast to filter base and get the required values
            if (filter != null)
            {
                var result = new DataSourceResult()
                {
                    Data = filter.Items,
                    Total = filter.TotalRecordsFound
                };
                //Return the result as JSON.
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            return Json("No Record Found");
        }

        [ValidateInput(false)]
        public JsonResult IndexAuditJson([DataSourceRequest] DataSourceRequest request, Data.AuditQueryFilter Model)
        {
            string sortColumn = "AmendedDate";
            string sortOrder = "ASC";
            if (request != null && request.Sorts != null && request.Sorts.Count > 0)
            {
                sortColumn = request.Sorts[0].Member;
                sortOrder = (request.Sorts[0].SortDirection == ListSortDirection.Ascending) ? "ASC" : "DESC";
            }
            var GeneralAudit = AuditManager.ListGeneralAuditGet(this.ReadOnlyContext);
            int TotalCount = GeneralAudit.Count;
            var type = typeof(Data.GeneralLevelAuditRecord);
            var sortProperty = type.GetProperty(sortColumn);
            if (sortOrder == "ASC")
                GeneralAudit = GeneralAudit.Skip(request.PageSize * (request.Page - 1)).Take(request.PageSize).OrderBy(p => sortProperty.GetValue(p, null)).ToList();
            else
                GeneralAudit = GeneralAudit.Skip(request.PageSize * (request.Page - 1)).Take(request.PageSize).OrderByDescending(p => sortProperty.GetValue(p, null)).ToList();
            if (GeneralAudit != null)
            {
                var result = new DataSourceResult()
                {
                    Data = GeneralAudit,
                    Total = TotalCount
                };
                //Return the result as JSON.
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            return Json("No Record Found");
        }

        #endregion .Methods.
    }
}