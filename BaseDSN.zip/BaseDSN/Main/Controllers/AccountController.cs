﻿#region .Imports

using Accent.Security.Business;
using Accent.Security.UI.Web.Core;
using Accent.Security.UI.Web.Models;
using System;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using System.Web.Security;
using System.Web.UI;

#endregion .Imports

namespace Accent.Security.UI.Web.Controllers
{
    /// <summary>
    /// Account controller.
    /// </summary>
    public class AccountController : Core.HicomController<Hicom.Core.Client.Security.SecurityUser, Hicom.Core.Client.Sql.Objects.QueryFilterBase>
    {
        #region .Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="AccountController" /> class.
        /// </summary>
        public AccountController()
        {
            base.AllowForPublicAccess();
        }

        #endregion .Constructors

        #region .Methods
        /// <summary>
        /// Access Denied.
        /// </summary>
        /// <returns></returns>
        [AllowAnonymous, BreadCrumb(PageTitle = "Access Denied")]
        public ActionResult AccessDenied()
        {
            return View();
        }
        /// <summary>
        /// Destroy the cookie.
        /// </summary>
        /// <param name="cookieName">Name of the cookie.</param>
        private void DestroyCookie(string cookieName)
        {
            System.Web.HttpCookie cookie = new System.Web.HttpCookie(cookieName, "");
            cookie.Expires = System.DateTime.Now.AddYears(-1);
            Response.Cookies.Add(cookie);
        }

        /// <summary>
        /// Destroys the session.
        /// </summary>
        public void DestroySession()
        {
            System.Web.Security.FormsAuthentication.SignOut();
            Accent.Security.Security.SecurityUserManager.LogOut();
            DestroyCookie(System.Web.Security.FormsAuthentication.FormsCookieName);
            DestroyCookie("ASP.NET_SessionId");
            DestroyCookie("userName");
            Session.Clear();
            this.HttpContext.Session.Clear();
            Response.Cache.SetNoStore();
            Response.AppendHeader("Pragma", "no-cache");
        }

        /// <summary>
        /// Login this instance.
        /// </summary>
        /// <returns></returns>
        [AllowAnonymous]
        public ActionResult Login()
        {
            return View();
        }

        /// <summary>
        /// Logins the specified value.
        /// </summary>
        /// <param name="Value">The value.</param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [HicomAntiForgeryToken]
        public ActionResult Login(LogOnModel Value)
        {
            string Result = string.Empty;
            Hicom.Core.Client.Security.SecurityUserQueryFilter Filter = new Hicom.Core.Client.Security.SecurityUserQueryFilter();
            Filter.SecurityUserName = Value.Username;
            Filter.SecurityPassword = Value.Password;
            if (Security.SecurityUserManager.ValidateUser(ref Filter))
            {
                var objTicket = new FormsAuthenticationTicket(1, Value.Username.Trim(), System.DateTime.Now, System.DateTime.Now.AddDays(1), false, "");
                var strEncryptedTicket = FormsAuthentication.Encrypt(objTicket);
                System.Web.HttpContext.Current.Response.Cookies.Add(new System.Web.HttpCookie(FormsAuthentication.FormsCookieName, strEncryptedTicket));
                return LoginStepCheckUser();
            }
            else
            {
                ModelState.AddModelError("Password", Filter.GetError("SecurityUserName"));
                ViewBag.LoginFailedMsg = LoginFailedMessage(Filter.GetError("SecurityUserName"));//"Login failed :  " + Filter.GetError("SecurityUserName");
            }

            return View(Value);
        }
        /// <summary>
        /// Login failed message.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <returns></returns>
        private string LoginFailedMessage(string message)
        {
            switch (message)
            {
                case "Unrecognised user":
                    message = "This email address is not registered.";
                    break;
                case "Invalid user name or password.":
                    message = "Password incorrect.";
                    break;
                default:
                    message = "Password incorrect.";
                    break;
            }
            return message;
        }

        /// <summary>
        /// Logins the step check user.
        /// </summary>
        /// <returns></returns>
        private ActionResult LoginStepCheckUser()
        {
            LoginUserInitialize();
            if (Accent.Security.Security.SecurityUserManager.CurrentUser == null)
                return RedirectToAction("Login", "Account");
            else
                ViewBag.Username = Security.SecurityUserManager.CurrentUser.Email;
            if (Request["ReturnUrl"] != null)
            {
                return RedirectToLocal(Request["ReturnUrl"]);
            }
            else
            {
                return RedirectToActionPermanent("Index", "Dashboard");
            }
        }
        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction("Index", "Dashboard");
            }
        }


        /// <summary>
        /// Logins the user initialize.
        /// </summary>
        private void LoginUserInitialize()
        {
            System.Web.Security.FormsAuthentication.SetAuthCookie(Accent.Security.Security.SecurityUserManager.CurrentUser.TokenId.ToString(), false);
            HttpContext.Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
            HttpContext.Response.ExpiresAbsolute = System.DateTime.Now.AddMonths(-1);
        }

        /// <summary>
        /// Logs the off.
        /// </summary>
        /// <returns></returns>
        [AllowAnonymous]
        public ActionResult LogOff()
        {
            DestroySession();
            return RedirectToActionPermanent("Login", "Account");
        }

       
        /// <summary>
        /// Logs off user from other site.
        /// </summary>
        /// <returns></returns>
        [Authorize]
        public ActionResult LogOffExternal()
        {
            DestroySession();
            ////Redirect user to Portal home page
            //var BackToPortalURL = "";
            //BackToPortalURL = Url.Action("Login", "Account");
            ////return new RedirectResult(BackToPortalURL);
            return View();
        }


        #endregion .Methods
    }
}
