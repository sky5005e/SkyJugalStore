﻿#region .Imports

using Accent.Security.Business;
using Accent.Security.UI.Web.Core;
using System;
using System.Web.Mvc;
using System.Web.Security;
using System.Web.UI;

#endregion .Imports

namespace Accent.Security.UI.Web.Controllers
{
    /// <summary>
    /// Dashboard controller.
    /// </summary>
    /// <seealso cref="Accent.Security.UI.Web.Core.HicomController{Accent.Security.Data.Setting, Hicom.Core.Client.Sql.Objects.QueryFilterBase}" />
    public class DashboardController : Core.HicomController<Data.Setting, Hicom.Core.Client.Sql.Objects.QueryFilterBase>
    {
        #region .Methods
        /// <summary>
        /// Called when [load].
        /// </summary>
        /// <returns></returns>
        [AllowAnonymous]
        [BreadCrumb(Title = "Home", RemoveAll = true)]
        public override ActionResult Index()
        {
            try
            {
                // For Testing purpose
                string ticketId = HttpContext.Request.QueryString["TicketID"];

                if (!string.IsNullOrEmpty(ticketId) && !System.Web.HttpContext.Current.User.Identity.IsAuthenticated)
                {
                    int UserId = Accent.Security.Business.AuthenticationServiceManager.ValidateToken(ticketId);
                    if (UserId > 0)// && SecurityUserLicenceManager.LicenceValid(UserId))
                    {
                        Accent.Security.Security.SecurityUserManager.CurrentUser = Security.SecurityUserManager.Load(Convert.ToInt32(UserId));
                        Hicom.Core.Client.Sql.General.Setting.CurrentUserId = CurrentUser.SecurityUserId;
                        System.Web.Security.FormsAuthentication.SetAuthCookie(ticketId, false);
                        SecurityUserAuthenticationLogManager.AuditLogAdd(Accent.Security.Security.SecurityUserManager.CurrentUser.Email, "Login", "Success", Accent.Security.Security.SecurityUserManager.CurrentUser.SecurityUserId);
                    }
                    else
                    {
                        SecurityUserAuthenticationLogManager.AuditLogAdd(System.Web.HttpContext.Current.User.Identity.Name, "Login", "Failure");
                        return Redirect(Business.Global.CommonManager.AccentLogoffURLGet());
                    }
                }
                else if (!System.Web.HttpContext.Current.User.Identity.IsAuthenticated)
                {
                    return Redirect(Business.Global.CommonManager.AccentLogoffURLGet());
                }

            }
            catch(Exception ex)
            {
                
                Sys.ErrorLogManager.Log(ex, "Audit Log for sign-in : exception");
                return Redirect(Business.Global.CommonManager.AccentLogoffURLGet());
            }
            return View();
        }
       
        /// <summary>
        /// Shows the new menus.
        /// </summary>
        /// <returns></returns>
        [OutputCache(Duration = 1, VaryByParam = "none", Location = OutputCacheLocation.Client, NoStore = true)]
        public ActionResult DashboardTiles()
        {
            var UserMenuItems = DashboardManager.GetDashboardMenuItemsBySecurityUserId(this.ReadOnlyContext, CurrentUser.SecurityUserId);

            return PartialView(UserMenuItems);            
        }
        


        /// <summary>
        /// Shows the new menus.
        /// </summary>
        /// <returns></returns>
        [OutputCache(Duration = 1, VaryByParam = "none", Location = OutputCacheLocation.Client, NoStore = true)]
        public ActionResult ShowNewMenuItems()
        {
            var MenuItems = DashboardManager.GetWidgetsBySecurityUserId(this.ReadOnlyContext, CurrentUser.SecurityUserId);
            return PartialView(MenuItems);
        }

        #endregion .Methods
    }
}
