﻿#region .Imports.

using Accent.Security.Business;
using Accent.Security.UI.Web.Core;
using System;
using System.Collections.Generic;
using System.Web.Mvc;
using System.Web.UI;

#endregion .Imports.

namespace Accent.Security.UI.Web.Controllers
{
    /// <summary>
    /// Home controller 
    /// </summary>
    public class HomeController : Core.HicomController<Data.Setting, Hicom.Core.Client.Sql.Objects.QueryFilterBase>
    {
        #region .Methods.

        /// <summary>
        /// Information the page.
        /// </summary>
        /// <param name="type">The type.</param>
        [BreadCrumb(Title = "Type")]
        public ActionResult InformationPage(string type)
        {
            try
            {
                if (type == null)
                    return RedirectToAction("Login", "Account");

                Data.Sys_Content content = Sys.ContentManager.GetContentByName(this.ReadOnlyContext, type);

                if (content != null)
                {
                    ViewBag.Title = content.ContentValue;
                    Session["SiteMapTitle"] = content.ContentValue;
                    ViewBag.Description = content.ContentFull;
                    return View();
                }
                else
                    return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                Sys.ErrorLogManager.Log(ex, "Controller: HomeController & Action: InformationPageData");
                return RedirectToAction("Index", "Error", new { area = "", code = "" });
            }
        }
        /// <summary>
        /// Landings the page.
        /// </summary>
        /// <returns></returns>
        [OutputCache(Duration = 1, VaryByParam = "none", Location = OutputCacheLocation.Client, NoStore = true)]
        public PartialViewResult LandingPage(string type)
        {
            List<Data.Sys_Content> content = Sys.ContentManager.GetLandingPageContent(this.ReadOnlyContext,type);
            return PartialView("_LandingPageContent", content);
        }
        #endregion .Methods.
    }
}
