﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Accent.Security.UI.Web.Controllers
{
    public class ErrorController : Core.HicomController<Hicom.Core.Client.Security.SecurityUser, Hicom.Core.Client.Sql.Objects.QueryFilterBase>
    {
        public override ActionResult Index()
        {

            return View();
        }
    }
}
