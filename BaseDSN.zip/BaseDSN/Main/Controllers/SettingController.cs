﻿#region Imports

using Accent.Security.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

#endregion

namespace Accent.Security.UI.Web.Controllers
{
    /// <summary>
    /// </summary>
    [Core.HicomAuthorize(SecurityObject = "Setting")]
    public class SettingController : Core.SecurityBaseController<Hicom.Core.Client.Security.Setting, Hicom.Core.Client.Security.SettingQueryFilter>
    {
        #region Methods

        /// <summary>
        /// Edits the specified data.
        /// </summary>
        /// <param name="data">The data.</param>
        /// <param name="RequireValidation">if set to <c>true</c> [require validation].</param>
        /// <returns></returns>
        ///  We need to in validate for HTML text editor hence we are are overriding this method.
        [HttpPost, ValidateInput(false)]
        public override ActionResult Edit(Hicom.Core.Client.Security.Setting data, bool RequireValidation = true)
        {
            return base.Edit(data, RequireValidation);
        }

        /// <summary>
        /// Called when [load].
        /// </summary>
        /// <returns></returns>
        public override ActionResult Index()
        {
            Hicom.Core.Client.Security.SettingQueryFilter Filter = new Hicom.Core.Client.Security.SettingQueryFilter();
            if (string.IsNullOrEmpty(Filter.SortBy)) Filter.SortBy = "SettingName";
            this.ApplyFilter(ref Filter);
            this.SearchFilter = Filter;
            ViewBag.Take = Filter.Take;
            Sys.SettingManager.PopulateModel((Hicom.Core.Client.Security.SettingQueryFilter)this.SearchFilter);
            return View(this.SearchFilter);
        }

        /// <summary>
        /// Called when [load].
        /// </summary>
        /// <param name="Filter">The filter.</param>
        /// <returns></returns>
        [HttpPost]
        public override ActionResult Index(Hicom.Core.Client.Security.SettingQueryFilter Filter)
        {
            if (string.IsNullOrEmpty(Filter.SortBy)) Filter.SortBy = "SettingName";
            this.ApplyFilter(ref Filter);
            this.SearchFilter = Filter;
            ViewBag.Take = Filter.Take;
            Sys.SettingManager.PopulateModel((Hicom.Core.Client.Security.SettingQueryFilter)this.SearchFilter);
            return View(this.SearchFilter);
        }

        /// <summary>
        /// Called when [load].
        /// </summary>
        /// <param name="id">The id.</param>
        /// <returns></returns>
        public override object OnLoad(int? id)
        {
            Hicom.Core.Client.Security.Setting Model = null;
            if (typeof(Hicom.Core.Client.Security.Setting).BaseType == typeof(Hicom.Core.Client.Sql.Objects.EntityObjectBase) && id.HasValue && id.Value != 0)
                Model = Sys.SettingManager.GetSettingById(id.Value);
            return Model;
        }

        /// <summary>
        /// Called when [save].
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public override bool OnSave(Hicom.Core.Client.Security.Setting value)
        {
            return Sys.SettingManager.Save(value);
        }

        #endregion
    }
}
