﻿#region Imports

using System.Collections.Generic;
using System.Web.Mvc;
using System.Linq;

#endregion Imports

namespace Accent.Security
{
    public static class StaticDropDownListItem
    {
        #region Properties
        /// <summary>
        /// Returns values for Active field.
        /// </summary>
        public static IEnumerable<SelectListItem> ActiveStatus
        {
            get
            {
                return new[]
                {
                    new SelectListItem { Value = "True", Text = "Active", Selected = true },
                    new SelectListItem { Value = "False", Text = "Inactive" }
                };
            }
            set { }
        }


        /// <summary>
        /// Returns values for Active field.
        /// </summary>
        public static IEnumerable<SelectListItem> Category()
        {
            List<SelectListItem> Category = new List<SelectListItem>();
            var SecurityObjectCategory = Security.SecurityObjectManager.GetSecurityObjectCategory().GroupBy(p => p.Category).Select(g => g.FirstOrDefault());
            foreach (var item in SecurityObjectCategory)
            {
                Category.Add(new SelectListItem
                {
                    Text = item.Category,
                    Value = item.Category,
                });
            }
            return Category;
        }




        /// <summary>
        /// Returns values for Active field.
        /// </summary>
        //public static IEnumerable<SelectListItem> Category
        //{
        //    get
        //    {
        //        return new[]
        //        {
        //            new SelectListItem { Value = "", Text = "" },
        //            new SelectListItem { Value = "Admin", Text = "Administrator Object"},
        //            new SelectListItem { Value = "NonAdmin", Text = "Non-administrator Object" }
        //        };
        //    }
        //    set { }
        //}

        public static IEnumerable<SelectListItem> Default
        {
            get
            {
                return new[]
                {
                    new SelectListItem { Value = "False", Text = "No" },
                    new SelectListItem { Value = "True", Text = "Yes", Selected = true }
                };
            }
            set { }
        }


        /// <summary>
        /// Returns values for Active field.
        /// </summary>
        public static IEnumerable<SelectListItem> UserRoleType
        {
            get
            {
                return new[]
                {
                    new SelectListItem { Value = "Administrator", Text = "Administrator"},
                    new SelectListItem { Value = "Non-administrator", Text = "Non-administrator" }
                };
            }
            set { }
        }


        public static IEnumerable<SelectListItem> Type
        {
            get
            {
                return new[]
                {
                    new SelectListItem { Value = "Full", Text = "Full" },
                    new SelectListItem { Value = "Limited", Text = "Limited" }
                };
            }
            set { }
        }



        public static IEnumerable<SelectListItem> DropNonAdminStatus
        {
            get
            {
                return new[]
                {
                    new SelectListItem { Value = "Current", Text = "Active", Selected = true },
                    new SelectListItem { Value = "Inactive", Text = "Inactive" }
                };
            }
            set { }
        }
        #endregion Properties
    }
}


