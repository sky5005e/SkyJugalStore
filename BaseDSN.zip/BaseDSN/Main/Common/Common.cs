﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Accent.Security.UI.Web
{
    public static class Common
    {
        public static void ImageRatio(string imagePath, ref int ActualWidth, ref int ActualHeight)
        {
            try
            {
                System.Drawing.Image image = System.Drawing.Image.FromFile(HttpContext.Current.Server.MapPath(imagePath));
                if (image.Width < ActualWidth)
                {
                    ActualWidth = image.Width;
                }
                if (image.Height < ActualHeight)
                {
                    ActualHeight = image.Height;
                }
            }
            catch(Exception ex)
            {

            }
        }


        #region Message

        public const string DeleteSuccessMessage = "Deleted successfully.";
        public const string DeleteFailureMessage = "There were some issues deleting, please try again later.";

        public const string RecoverSuccessMessage = "Recovered successfully.";
        public const string RecoverFailureMessage = "There were some issues recovering, please try again later.";

        public const string SaveSuccessMessage = "Saved successfully.";
        public const string SaveFailureMessage = "There were some issues saving, please try again later.";

        public const string NonUniqueMessage = "Record with same unique value already exists, please update and try to save again.";

        #endregion Message

        #region Status

        public const string ActionSuccessResult = "Passed";
        public const string ActionFailureResult = "Failed";

        #endregion Status

    }
}