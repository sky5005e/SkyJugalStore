﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Accent.Security.UI.Web")]
[assembly: AssemblyProduct("Accent.Security.UI.Web")]
[assembly: Guid("bfc2a39e-0e7c-4b82-ba15-0b7625d0dc83")]