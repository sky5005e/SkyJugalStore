﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Accent.Security.UI.Web.Models
{
    public class LogOnModel
    {

        #region .Properties.

        /// <summary>
        /// Gets or sets the name of the user.
        /// </summary>
        /// <value>
        /// The name of the user.
        /// </value>
        public string  Username{ get; set; }

        /// <summary>
        /// Gets or sets the password.
        /// </summary>
        /// <value>
        /// The password.
        /// </value>
        public string Password { get; set; }

        /// <summary>
        /// Gets or sets the user pin.
        /// </summary>
        /// <value>
        /// The user pin.
        /// </value>
       // public string UserPin { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [remeber me].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [remeber me]; otherwise, <c>false</c>.
        /// </value>
        public bool RemeberMe { get; set; }
          #endregion .Properties.
    }
}