﻿#region Imports

using System.Web.Mvc;

#endregion

namespace Accent.Security.UI.Web
{
    /// <summary>Filter configuration.</summary>
    public static class FilterConfig
    {
        #region Methods

        /// <summary>Registers the global filters described by filters.</summary>
        /// <param name="filters">The filters.</param>
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }

        #endregion
    }
}
