﻿#region .Imports

using System.Web.Mvc;
using System.Web.Routing;

#endregion .Imports

namespace Accent.Security.UI.Web
{
    /// <summary>
    /// Route configuration.
    /// </summary>
    public static class RouteConfig
    {
        #region .Methods

        /// <summary>
        /// Registers the routes described by routes.
        /// </summary>
        /// <param name="routes">The routes.</param>
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Dashboard", action = "Index", id = UrlParameter.Optional },
                namespaces: new string[] { "Accent.Security.UI.Web.Controllers" });
        }

        #endregion .Methods
    }
}
