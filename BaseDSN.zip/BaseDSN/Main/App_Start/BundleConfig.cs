﻿#region .Imports

using System;
using System.Web.Optimization;

#endregion .Imports

namespace Accent.Security.UI.Web
{
    /// <summary>Bundle configuration.</summary>
    public static class BundleConfig
    {
        #region .Methods
        public static void AddDefaultIgnorePatterns(IgnoreList ignoreList)
        {
            if (ignoreList == null)
                throw new ArgumentNullException("ignoreList");
            ignoreList.Ignore("*.intellisense.js");
            ignoreList.Ignore("*-vsdoc.js");
            ignoreList.Ignore("*.debug.js", OptimizationMode.WhenEnabled);
            //ignoreList.Ignore("*.min.js", OptimizationMode.WhenDisabled);
            //ignoreList.Ignore("*.min.css", OptimizationMode.WhenDisabled);
        }
        /// <summary>Registers the bundles described by bundles.</summary>
        /// <param name="bundles">The bundles.</param>
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.IgnoreList.Clear();
            AddDefaultIgnorePatterns(bundles.IgnoreList);

            bundles.Add(new StyleBundle("~/Content/sitecss").Include(
                    "~/Content/css/bootstrap.css",
                    "~/Content/css/jquery-ui.css",
                    "~/Content/css/font-awesome.css",
                    "~/Content/css/Hicom.css"));

            bundles.Add(new StyleBundle("~/Content/kendo/css").Include(
                   "~/Content/css/kendo/kendo.bootstrap.min.css",
                   "~/Content/css/kendo/kendo.common-bootstrap.min.css",
                   "~/Content/css/kendo/kendo.material.min.css",
                   "~/Content/css/kendo/kendo.common.min.css"));

            bundles.Add(new ScriptBundle("~/bundles/script").Include(
                      "~/Scripts/jquery.js",
                      "~/Scripts/bootstrap.js",
                      "~/Scripts/jquery.lbslider.js",
                      "~/Scripts/jquery.latest.js",
                      "~/Scripts/jquery.dragsort-0.5.2.js",
                      "~/Scripts/jquery-ui.js",
                      "~/Scripts/bootbox.js",
                      "~/Scripts/Hicom.js",
                      "~/Scripts/jquery.unobtrusive-ajax.js",
                      "~/Scripts/jquery.nicescroll.js",
                      "~/Scripts/jquery.autocomplete.js"));

            bundles.Add(new ScriptBundle("~/bundles/Scripts/kendo").Include(
                        "~/Scripts/kendo/kendo.all.min.js",
                         "~/Scripts/kendo/kendo.aspnetmvc.min.js",
                          "~/Scripts/kendo/kendo.timezones.min.js"));

            bundles.Add(new ScriptBundle("~/bundles/Scripts/ckeditor").Include(
                    "~/Scripts/ckeditor/ckeditor.js",
                    "~/Scripts/bootstrap-ckeditor-modal-fix.js"));

            bundles.Add(new ScriptBundle("~/bundles/Scripts/ckeditor/adapters").Include(
                   "~/Scripts/ckeditor/adapters/jquery.js"));

            BundleTable.EnableOptimizations = false;
        }

        #endregion .Methods
    }
}
