﻿
//Smooth scroll down from Home/Login page banner
$(function () {
    //CKEDITOR.replace('.ckeditor');
    $('.ckeditor').ckeditor();
    $(".validate-datepicker").datepicker({
        dateFormat: 'dd/mm/yy'
    });

    $(".datepicker").datepicker({
        dateFormat: 'dd/mm/yy',
    });
    $('#latestnews').click(function () {
        if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
            if (target.length) {
                $('html,body').animate({
                    scrollTop: target.offset().top
                }, 1000);
                return false;
            }
        }
    });
});
// page filter for Grid client side
$(document).keypress(function (e) {
    if (e.keyCode == 13) {
        $("a.k-pager-refresh").trigger("click");
    }
});
$(function () {
    $(".search-filter").click(function () {
        $("a.k-pager-refresh").trigger("click");
    });
    $(".reset-filter").click(function () {
        //$(this).closest('form').find("input[type=text], textarea").val("");
        $("form").trigger('reset');
        $("a.k-pager-refresh").trigger("click");
    });
});
/**
 * Returns a random integer between min (inclusive) and max (inclusive)
 * Using Math.round() will give you a non-uniform distribution!
 */
function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
function SerializeObject(formArray) {
    var Object = {};
    $.each(formArray,
        function (i, v) {
            Object[v.name] = v.value;
        });
    return Object;
}

function SerializeFormData() {
    var Data = {};
    var DataArray = $('form').serializeArray();
    $.each(DataArray,
        function (i, v) {
            Data[v.name] = v.value;
        });

    return Data;
}

function AppendToFormObject(FormData, formArray) {
    $.each(formArray,
        function (i, v) {
            FormData.append(v.name, v.value);
        });
    return FormData;
}

function ToggleImg(val) {
    if (val) {
        $("#photoimg1").show();
        $("#photoicon").hide();
    }
    else {
        $("#photoimg1").hide();
        $("#photoicon").show();
    }
}
// Handle File Select
function HandleFileSelect(evt, elementId, extwithcomma) {
    var _img = document.getElementById(elementId);
    var files = evt.target.files; // FileList object
    var extension = files[0].name.split('.').pop().toLowerCase();
    if (extwithcomma.toLowerCase().indexOf(extension) >= 0) {
        var reader = new FileReader();
        // Closure to capture the file information.
        reader.onload = (function (theFile) {
            return function (e) {
                _img.src = e.target.result;
            };
        })(files[0]);
        // Read in the image file as a data URL.
        reader.readAsDataURL(files[0]);
        ToggleImg(true);
        return true;
    }
    else {
        alert("Please select a valid file " + extwithcomma);
        return false;
    }
}

function $PostFile(postUrl, formData, fnSuccessCallBack, fnErrorCallBack) {
    $.ajax({
        type: "POST",
        url: postUrl,
        data: formData,//JSON.stringify(model),
        processData: false,
        contentType: false,
        dataType: "json",
        success: function (msg) {
            if (fnSuccessCallBack != undefined) {
                fnSuccessCallBack(msg);
            }
        },
        error: function (xhr, errStatus, error) {
            //alert(xhr.responseText);
            if (fnErrorCallBack == undefined) {
                alert(error + " " + errStatus)
            } else {
                fnErrorCallBack(error, errStatus);
            }
        }
    });
}

function $PostJson(pUrl, data, fnSuccessCallBack, fnErrorCallBack) {
    $.ajax({
        type: "POST",
        url: pUrl,
        data: JSON.stringify(data),
        dataType: 'json',
        contentType: 'application/json; charset=utf-8',
        success: function (msg) {
            if (fnSuccessCallBack != undefined) {
                fnSuccessCallBack(msg);
            }
        },
        error: function (xhr, errStatus, error) {
            //alert(xhr.responseText);
            if (fnErrorCallBack == undefined) {
                alert(error + " " + errStatus)
            } else {
                fnErrorCallBack(error, errStatus);
            }
        }
    });
}

function HandleGridAction(arg) {
    var selected = $.map(this.select(), function (item) {
        window.location.href = $(item).find('.EditRecord')[0].href;
    });
}

function ConfirmationBox(message, title, actionURL, onYesFunctionToExecute, onYesRenderSection) {
    bootbox.dialog({
        message: message,
        title: title,
        buttons: {
            danger: {
                label: "Yes",
                className: "btn btn-primary ConfirmDialogButtons",
                callback: function () {
                    if (onYesFunctionToExecute != null && onYesFunctionToExecute != undefined && onYesFunctionToExecute != "") {
                        onYesFunctionToExecute(actionURL, onYesRenderSection);
                    }
                    else if (location != null && location != undefined && location != "") {
                        window.location.href = actionURL;
                    }
                }
            },
            success: {
                label: "No",
                className: "btn btn-primary ConfirmDialogButtons"
            }
        }
    });
}

// Code for paging in grid view list 
function PagedList(isAjax) {
    var selectorPreffix = '';
    if (isAjax) { selectorPreffix = '#frmAjaxSearch '; }
    $(selectorPreffix + "#Take option").each(function () { $(this).removeAttr('selected'); });
    $(selectorPreffix + "#Take option[value=" + $.trim($(selectorPreffix + "#PageSize").val()) + "]").attr('selected', 'selected');
    $(selectorPreffix + "#ActivePage").val($.trim($(selectorPreffix + "#CurrentPage").val()));/* For IE7 also */
}

function PageRefresh(isAjax) {
    var btnSearch;
    if (isAjax) { btnSearch = jQuery('#btnAjaxSearch'); }
    else {
        btnSearch = jQuery('#btnSearch');
        searchMode = 'indirect';
    }
    btnSearch.click();
}

//Code for paging
function PageCommand(pg, isAjax) {
    var idSelector = '#ID';
    if (isAjax) { idSelector = '#frmAjaxSearch #ID'; }
    $(idSelector).val(pg);
    if ($(idSelector).val() > 0) {
        PageRefresh(isAjax);
    }
    return false;
}

//Condition to validate Numeric value
function OnlyNumeric(e) {
    var keyCode = e.keyCode || e.charCode;
    if ((keyCode < 48 || keyCode > 57)) {
        if (keyCode === 8 || keyCode === 46 || keyCode === 0 || keyCode === 37 || keyCode === 47 || keyCode === 39 || keyCode === 11 || keyCode === 9) {
            return true;
        }
        else {
            return false;
        }
    }
}
function ValidatePin(txt) {
    var regex = /^(?:-?\d+|-?\d{1,3}(?:,\d{3})+)?(?:\.\d+)?$/;
    var ok = regex.test($(txt).val());
    if (!ok) {
        $(txt).val('');
        $(txt).attr("title", "Pin entered is incorrect must be numeric.");
        $(txt).css("border", "1px solid red");
    }
    else {
        if ($(txt).val().length <= 4) {
            txt.setCustomValidity("Pin number must be 5 digit");// to change the custom message
            $(".btn-primary").attr("disabled", "disabled");
            $(txt).css("border", "1px solid red");
        }
        else {
            txt.setCustomValidity('');
            $(".btn-primary").removeAttr("disabled");
        }
    }
}
//Dialog box to confirm  - Before deleting any record 
function deleteWithConfirm() {
    if (window.confirm('Are you sure you want to delete this record?')) {
        return true;
    }
    return false;
}

// Clear values from specified control 
function FilterClear(formID) {

    //Check if Form ID is provided, if it is then fields on particular form needs clearing
    if (formID != undefined && formID != null && formID != "") {
        //Get Form based on Form ID
        oForm = document.forms[formID];

        //Set default value for Active field which is a record status and should only show active records (Active = true) by default 
        //Get DropDownList based on ID and set default value
        ddlActive = oForm.elements["Active"];
        ddlActive.value = "True";

        //Get all Dropdown fields
        Select = oForm.getElementsByTagName("select");
        //Loop through each to set default value
        for (var i = 0; i < Select.length; i++) {
            //Set first item as default value; ignore all Dropdown list with ID Active,
            //as default value for it is different and it is being set above
            if (Select[i].id != "Active") {
                Select[i].selectedIndex = 0;
            }
        };

        //Get all input fields
        Input = oForm.getElementsByTagName("input");
        //Loop through each to set default value based on type
        for (var i = 0; i < Input.length; i++) {
            //Set default value for input type of Text
            if (Input[i].type == "text") {
                Input[i].value = "";
            }
                //Set default value for input type of Checkbox
            else if (Input[i].type == "checkbox") {
                Input[i].value = "false";
            }
        };
    }
        //Clear fields on all forms, as no Form ID is provided
    else {
        $("input[type=text]").val('');
        $("textarea").val('');
        $("#Language").val('');
        $("#Area").text('Any');
        $("#Subject").text('Any');
        $("#Location").text('Any');
        $("#Category").text('Any');
        $("#Status").val('Any');
        $("#SecurityUserId").text('Any');
        $("input[type=checkbox]").val('false');
        $("select").each(function () {
            var id = "#" + this.id;
            //Set default value for Active field which is a record status and should only show active records (Active = true) by default  
            if (id == "#Active") {
                $(id).val("True");
            }
            if (id !== "#Take" && id !== "#Active") {
                $(id).val($(id + " option:first").val());
            }
        });
    }

    return true;
}

//Method used for navigation to given url page
function MoveToPage(url) {
    window.location.href = $.trim(url);
    return false;
}

// Code to open Pop Up window with Jquery verison [jquery-2.2.3]
function OpenPopUp(url, width, height) {
    $("#DivPopup").dialog({
        autoOpen: true,
        position: { my: "center", at: "top+350", of: window },
        width: width,
        height: height,
        modal: true,
        open: function () {
            $(this).load(url);
            $("#divmask").show();
        }
    });
    return false;
}


//To close Pop Up window 
function closePopup() {
    $("#DivPopup").dialog('close');
    $("#divmask").hide();
}

//this is to add the verfication token to the data passed to a controller method.
//example usage  data: addRequestVerificationToken( {'SelectedApplicants': ids}) 
//data is the data parameter in a standard ajax call
function addRequestVerificationTokenToAJAXCall(data) {
    data.__RequestVerificationToken = $('input[name=__RequestVerificationToken]').val();
    return data;
};

//Viewing Reports 
function PreviewReport(ReportName) {
    var url = "../ReportViewer/ReportViewer.aspx?ReportName=" + ReportName;
    var iMyWidth;
    var iMyHeight;
    var windowWidth = parseInt(window.screen.width) - parseInt((window.screen.width / 100) * 50)
    var windowHeight = parseInt(window.screen.height) - parseInt((window.screen.height / 100) * 50)
    //half the screen width minus half the new window width (plus 5 pixel borders).
    iMyWidth = (window.screen.width / 2) - (windowWidth / 2);
    //half the screen height minus half the new window height (plus title and status bars).
    iMyHeight = (window.screen.height / 2) - (windowHeight / 2);
    //Open the window.
    var win2 = window.open(url, ReportName, "status=no,height=" + windowHeight + ",width=" + windowWidth + ",resizable=yes,left=" + iMyWidth + ",top=" + iMyHeight + ",screenX=" + iMyWidth + ",screenY=" + iMyHeight + ",toolbar=no,menubar=no,scrollbars=yes,location=no,directories=no");
    win2.focus();
}

function ValidateForm(formid, ctrltovalidate, msg) {
    $("#divmsg").show();
    $("#errormsg").text(msg);
}
function ValidateFramwork(formid, ctrltovalidate, msg) {
    $(ctrltovalidate).attr("title", msg);
    $(ctrltovalidate).css("border", "1px solid red");
}

function HideMsg() {
    $("#divmsg").hide();
}
function ShowMsg(msg, issucess) {
    if (issucess) {
        // remove alert-danger class
        $("#divcls").removeClass("alert-danger")
        $("#divcls").addClass("alert-success");
    }
    else {
        $("#divcls").addClass("alert-danger");
    }
    $("#divmsg").show();
    $("#errormsg").text(msg);
}

function checkEmail(email) {
    var regExp = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/
    return regExp.test(email);
}

//********************** START - Bootstrap Accordion State ******************************
//Set cookie to maintain Bootstrap Accordion state on postback
function setCookie(sectionName) {
    var lastState = getCookie(sectionName);
    if (lastState == "" || lastState == "off") {
        document.cookie = sectionName + "=on";
    }
    else {
        document.cookie = sectionName + "=off";
    }
}

//Get saved cookie to maintain Bootstrap Accordion state on postback
function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1);
        if (c.indexOf(name) != -1) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

//Set Bootstrap Accordion state on postback
function setState(panelName, buttonName) {

    //Declare variables
    var detailPanelClass = "";
    var toggleButtonClass = "";

    if (getCookie(panelName) == "" || getCookie(panelName) == "off") {
        //Get class for panel in collapsed mode
        detailPanelClass = "tab-container collapse";

        //Get class for toggle button in collapsed mode
        toggleButtonClass = "collapsed";
    }
    else {
        //Get class for panel in expanded mode
        detailPanelClass = "tab-container in";

        //Get class for toggle button in expanded mode
        toggleButtonClass = "";
    }

    //Set class of panel
    document.getElementById(panelName).className = detailPanelClass;

    //Set class of toggle button
    document.getElementById(buttonName).className = toggleButtonClass;
}
//********************** END - Bootstrap Accordion State ******************************

//********************** START - Confirm Popup and AJAX Partial Render ******************************

//Render HTML (populated by provided URL) partially on provided target (RenderSection)
function AJAXPartialRender(ActionURL, RenderSection) {

    //Render section ID must be prefixed with '#'
    if (RenderSection.substring(0, 1) != '#') {
        RenderSection = '#' + RenderSection;
    }

    $.ajax({
        type: "POST",
        url: ActionURL,
        dataType: "html",
        success: function (data, textStatus, jqXHR) {
            $(RenderSection).html(data);
        }
    });
}

//Confirm action on popup and render partial view
function ConfirmActionAndAJAXPartialRender(Action, ActionURL, ActionMessage, FunctionToExecute, RenderSection) {

    //Set confirm message
    ActionMessage = ConfirmMessageSet(Action, ActionMessage);

    //Populate confirm box
    ConfirmationBox(ActionMessage, Action, ActionURL, FunctionToExecute, RenderSection);
}

//Confirm action on popup and render partial view
function ConfirmMessageSet(Action, ActionMessage) {
    if (ActionMessage == undefined || ActionMessage == null || ActionMessage == "") {
        if (Action == "Delete") {
            ActionMessage = "Are you sure you want to delete?";
        }
        else if (Action == "Recover") {
            ActionMessage = "Are you sure you want to recover?";
        }
    }

    if (ActionMessage == undefined || ActionMessage == null) {
        ActionMessage = "";
    }
    return ActionMessage;
}

//Show success/failure message on data action (Delete, Recover, Save)
function SuccessFailureMessageShow(ActionResult, ActionResultMessage) {
    if (ActionResultMessage != undefined && ActionResultMessage != null && ActionResultMessage.length > 1) {
        if (ActionResult == "Failed") {
            ShowMsg(ActionResultMessage, false);
        }
        else {
            ShowMsg(ActionResultMessage, true);
        }
    }
}

//Proceed to close popup
function ClosePopupProceed() {

    //Call click event of Popup to close popup window
    $("#PopupWindow .close").click();
}

//Refresh parent page
function ParentPageRefresh(ChildFormID, ParentFormID) {

    //Check whether child form exist based on child form ID
    if (ChildFormID != undefined && ChildFormID != null && ChildFormID != "") {

        //Get child form based on child form ID
        ChildForm = document.forms[ChildFormID];

        //Get Submit Type on child form
        hdnSubmitType = ChildForm.elements["hdnSubmitType"];
        var SubmitType = hdnSubmitType.value;

        //Check whether submit type is Save
        if (SubmitType != undefined && SubmitType != null && SubmitType != ""
            && (SubmitType == "Save" || SubmitType == "SaveBack")) {

            //If submit type was Save, check whether parent form exist based on parent form ID
            if (ParentFormID != undefined && ParentFormID != null && ParentFormID != "") {

                //Get parent form based on parent form ID
                ParentForm = document.forms[ParentFormID];

                //Get Search button based on parent form
                btnSearch = ParentForm.elements["btnSearch"];

                //Call click event of Search button on parent form to refresh parent page
                btnSearch.click();
            }
        }
    }
}

//********************** END - Confirm Popup and AJAX Partial Render ******************************