!function (a) {
    "function" === typeof define && define.amd ? define(["jquery"], a) : a(jQuery);
}(function (a) {
    var b = !1, c = !1, d = 5e3, e = 2e3, f = 0, g = ["ms", "moz", "webkit", "o"], h = window.requestAnimationFrame || !1, i = window.cancelAnimationFrame || !1;
    if (!h) for (var j in g) {
        var k = g[j];
        h || (h = window[k + "RequestAnimationFrame"]);
        i || (i = window[k + "CancelAnimationFrame"] || window[k + "CancelRequestAnimationFrame"]);
    }
    var l = window.MutationObserver || window.WebKitMutationObserver || !1, m = {
        zindex: "auto",
        cursoropacitymin: 0,
        cursoropacitymax: 1,
        cursorcolor: "#0e4747",
        cursorwidth: "8px",
        cursorborder: "",
        cursorborderradius: "5px",
        scrollspeed: 60,
        mousescrollstep: 24,
        touchbehavior: !1,
        hwacceleration: !0,
        usetransition: !0,
        boxzoom: !1,
        dblclickzoom: !0,
        gesturezoom: !0,
        grabcursorenabled: !0,
        autohidemode: !0,
        background: "",
        iframeautoresize: !0,
        cursorminheight: 32,
        preservenativescrolling: !0,
        railoffset: !1,
        bouncescroll: !0,
        spacebarenabled: !0,
        railpadding: {
            top: 0,
            right: 0,
            left: 0,
            bottom: 0
        },
        disableoutline: !0,
        horizrailenabled: !0,
        railalign: "right",
        railvalign: "bottom",
        enabletranslate3d: !0,
        enablemousewheel: !0,
        enablekeyboard: !0,
        smoothscroll: !0,
        sensitiverail: !0,
        enablemouselockapi: !0,
        cursorfixedheight: !1,
        directionlockdeadzone: 6,
        hidecursordelay: 400,
        nativeparentscrolling: !0,
        enablescrollonselection: !0,
        overflowx: !0,
        overflowy: !0,
        cursordragspeed: .3,
        rtlmode: "auto",
        cursordragontouch: !1,
        oneaxismousemode: "auto",
        scriptpath: function () {
            var a = document.getElementsByTagName("script"), a = a[a.length - 1].src.split("?")[0];
            return 0 < a.split("/").length ? a.split("/").slice(0, -1).join("/") + "/" : "";
        }()
    }, n = !1, o = function () {
        if (n) return n;
        var a = document.createElement("DIV"), b = {
            haspointerlock: "pointerLockElement" in document || "mozPointerLockElement" in document || "webkitPointerLockElement" in document
        };
        b.isopera = "opera" in window;
        b.isopera12 = b.isopera && "getUserMedia" in navigator;
        b.isoperamini = "[object OperaMini]" === Object.prototype.toString.call(window.operamini);
        b.isie = "all" in document && "attachEvent" in a && !b.isopera;
        b.isieold = b.isie && !("msInterpolationMode" in a.style);
        b.isie7 = b.isie && !b.isieold && (!("documentMode" in document) || 7 == document.documentMode);
        b.isie8 = b.isie && "documentMode" in document && 8 == document.documentMode;
        b.isie9 = b.isie && "performance" in window && 9 <= document.documentMode;
        b.isie10 = b.isie && "performance" in window && 10 <= document.documentMode;
        b.isie9mobile = /iemobile.9/i.test(navigator.userAgent);
        b.isie9mobile && (b.isie9 = !1);
        b.isie7mobile = !b.isie9mobile && b.isie7 && /iemobile/i.test(navigator.userAgent);
        b.ismozilla = "MozAppearance" in a.style;
        b.iswebkit = "WebkitAppearance" in a.style;
        b.ischrome = "chrome" in window;
        b.ischrome22 = b.ischrome && b.haspointerlock;
        b.ischrome26 = b.ischrome && "transition" in a.style;
        b.cantouch = "ontouchstart" in document.documentElement || "ontouchstart" in window;
        b.hasmstouch = window.navigator.msPointerEnabled || !1;
        b.ismac = /^mac$/i.test(navigator.platform);
        b.isios = b.cantouch && /iphone|ipad|ipod/i.test(navigator.platform);
        b.isios4 = b.isios && !("seal" in Object);
        b.isandroid = /android/i.test(navigator.userAgent);
        b.trstyle = !1;
        b.hastransform = !1;
        b.hastranslate3d = !1;
        b.transitionstyle = !1;
        b.hastransition = !1;
        b.transitionend = !1;
        for (var c = ["transform", "msTransform", "webkitTransform", "MozTransform", "OTransform"], d = 0; d < c.length; d++) if ("undefined" != typeof a.style[c[d]]) {
            b.trstyle = c[d];
            break;
        }
        b.hastransform = !1 != b.trstyle;
        b.hastransform && (a.style[b.trstyle] = "translate3d(1px,2px,3px)", b.hastranslate3d = /translate3d/.test(a.style[b.trstyle]));
        b.transitionstyle = !1;
        b.prefixstyle = "";
        b.transitionend = !1;
        for (var c = "transition webkitTransition MozTransition OTransition OTransition msTransition KhtmlTransition".split(" "), e = " -webkit- -moz- -o- -o -ms- -khtml-".split(" "), f = "transitionend webkitTransitionEnd transitionend otransitionend oTransitionEnd msTransitionEnd KhtmlTransitionEnd".split(" "), d = 0; d < c.length; d++) if (c[d] in a.style) {
            b.transitionstyle = c[d];
            b.prefixstyle = e[d];
            b.transitionend = f[d];
            break;
        }
        b.ischrome26 && (b.prefixstyle = e[1]);
        b.hastransition = b.transitionstyle;
        a: {
            c = ["-moz-grab", "-webkit-grab", "grab"];
            if (b.ischrome && !b.ischrome22 || b.isie) c = [];
            for (d = 0; d < c.length; d++) if (e = c[d], a.style.cursor = e, a.style.cursor == e) {
                c = e;
                break a;
            }
            c = "url(http://www.google.com/intl/en_ALL/mapfiles/openhand.cur),n-resize";
        }
        b.cursorgrabvalue = c;
        b.hasmousecapture = "setCapture" in a;
        b.hasMutationObserver = !1 !== l;
        return n = b;
    }, p = function (g, j) {
        function k() {
            var a = s.win;
            if ("zIndex" in a) return a.zIndex();
            for (; 0 < a.length && 9 != a[0].nodeType;) {
                var b = a.css("zIndex");
                if (!isNaN(b) && 0 != b) return parseInt(b);
                a = a.parent();
            }
            return !1;
        }
        function n(a, b, c) {
            b = a.css(b);
            a = parseFloat(b);
            return isNaN(a) ? (a = x[b] || 0, c = 3 == a ? c ? s.win.outerHeight() - s.win.innerHeight() : s.win.outerWidth() - s.win.innerWidth() : 1,
            s.isie8 && a && (a += 1), c ? a : 0) : a;
        }
        function p(a, b, c, d) {
            s._bind(a, b, function (d) {
                d = d ? d : window.event;
                var e = {
                    original: d,
                    target: d.target || d.srcElement,
                    type: "wheel",
                    deltaMode: "MozMousePixelScroll" == d.type ? 0 : 1,
                    deltaX: 0,
                    deltaZ: 0,
                    preventDefault: function () {
                        d.preventDefault ? d.preventDefault() : d.returnValue = !1;
                        return !1;
                    },
                    stopImmediatePropagation: function () {
                        d.stopImmediatePropagation ? d.stopImmediatePropagation() : d.cancelBubble = !0;
                    }
                };
                "mousewheel" == b ? (e.deltaY = -.025 * d.wheelDelta, d.wheelDeltaX && (e.deltaX = -.025 * d.wheelDeltaX)) : e.deltaY = d.detail;
                return c.call(a, e);
            }, d);
        }
        function r(a, b, c) {
            var d, e;
            0 == a.deltaMode ? (d = -Math.floor(a.deltaX * (s.opt.mousescrollstep / 54)), e = -Math.floor(a.deltaY * (s.opt.mousescrollstep / 54))) : 1 == a.deltaMode && (d = -Math.floor(a.deltaX * s.opt.mousescrollstep),
            e = -Math.floor(a.deltaY * s.opt.mousescrollstep));
            b && s.opt.oneaxismousemode && 0 == d && e && (d = e, e = 0);
            d && (s.scrollmom && s.scrollmom.stop(), s.lastdeltax += d, s.debounced("mousewheelx", function () {
                var a = s.lastdeltax;
                s.lastdeltax = 0;
                s.rail.drag || s.doScrollLeftBy(a);
            }, 15));
            if (e) {
                if (s.opt.nativeparentscrolling && c && !s.ispage && !s.zoomactive) if (0 > e) {
                    if (s.getScrollTop() >= s.page.maxh) return !0;
                } else if (0 >= s.getScrollTop()) return !0;
                s.scrollmom && s.scrollmom.stop();
                s.lastdeltay += e;
                s.debounced("mousewheely", function () {
                    var a = s.lastdeltay;
                    s.lastdeltay = 0;
                    s.rail.drag || s.doScrollBy(a);
                }, 15);
            }
            a.stopImmediatePropagation();
            return a.preventDefault();
        }
        var s = this;
        this.version = "3.5.4";
        this.name = "nicescroll";
        this.me = j;
        this.opt = {
            doc: a("body"),
            win: !1
        };
        a.extend(this.opt, m);
        this.opt.snapbackspeed = 80;
        if (g) for (var t in s.opt) "undefined" != typeof g[t] && (s.opt[t] = g[t]);
        this.iddoc = (this.doc = s.opt.doc) && this.doc[0] ? this.doc[0].id || "" : "";
        this.ispage = /^BODY|HTML/.test(s.opt.win ? s.opt.win[0].nodeName : this.doc[0].nodeName);
        this.haswrapper = !1 !== s.opt.win;
        this.win = s.opt.win || (this.ispage ? a(window) : this.doc);
        this.docscroll = this.ispage && !this.haswrapper ? a(window) : this.win;
        this.body = a("body");
        this.iframe = this.isfixed = this.viewport = !1;
        this.isiframe = "IFRAME" == this.doc[0].nodeName && "IFRAME" == this.win[0].nodeName;
        this.istextarea = "TEXTAREA" == this.win[0].nodeName;
        this.forcescreen = !1;
        this.canshowonmouseevent = "scroll" != s.opt.autohidemode;
        this.page = this.view = this.onzoomout = this.onzoomin = this.onscrollcancel = this.onscrollend = this.onscrollstart = this.onclick = this.ongesturezoom = this.onkeypress = this.onmousewheel = this.onmousemove = this.onmouseup = this.onmousedown = !1;
        this.scroll = {
            x: 0,
            y: 0
        };
        this.scrollratio = {
            x: 0,
            y: 0
        };
        this.cursorheight = 20;
        this.scrollvaluemax = 0;
        this.observerremover = this.observer = this.scrollmom = this.scrollrunning = this.isrtlmode = !1;
        do this.id = "ascrail" + e++; while (document.getElementById(this.id));
        this.hasmousefocus = this.hasfocus = this.zoomactive = this.zoom = this.selectiondrag = this.cursorfreezed = this.cursor = this.rail = !1;
        this.visibility = !0;
        this.hidden = this.locked = !1;
        this.cursoractive = !0;
        this.wheelprevented = !1;
        this.overflowx = s.opt.overflowx;
        this.overflowy = s.opt.overflowy;
        this.nativescrollingarea = !1;
        this.checkarea = 0;
        this.events = [];
        this.saved = {};
        this.delaylist = {};
        this.synclist = {};
        this.lastdeltay = this.lastdeltax = 0;
        this.detected = o();
        var u = a.extend({}, this.detected);
        this.ishwscroll = (this.canhwscroll = u.hastransform && s.opt.hwacceleration) && s.haswrapper;
        this.istouchcapable = !1;
        u.cantouch && u.ischrome && !u.isios && !u.isandroid && (this.istouchcapable = !0,
        u.cantouch = !1);
        u.cantouch && u.ismozilla && !u.isios && !u.isandroid && (this.istouchcapable = !0,
        u.cantouch = !1);
        s.opt.enablemouselockapi || (u.hasmousecapture = !1, u.haspointerlock = !1);
        this.delayed = function (a, b, c, d) {
            var e = s.delaylist[a], f = new Date().getTime();
            if (!d && e && e.tt) return !1;
            e && e.tt && clearTimeout(e.tt);
            if (e && e.last + c > f && !e.tt) s.delaylist[a] = {
                last: f + c,
                tt: setTimeout(function () {
                    s && (s.delaylist[a].tt = 0, b.call());
                }, c)
            }; else if (!e || !e.tt) s.delaylist[a] = {
                last: f,
                tt: 0
            }, setTimeout(function () {
                b.call();
            }, 0);
        };
        this.debounced = function (a, b, c) {
            var d = s.delaylist[a];
            new Date().getTime();
            s.delaylist[a] = b;
            d || setTimeout(function () {
                var b = s.delaylist[a];
                s.delaylist[a] = !1;
                b.call();
            }, c);
        };
        var v = !1;
        this.synched = function (a, b) {
            s.synclist[a] = b;
            !function () {
                v || (h(function () {
                    v = !1;
                    for (a in s.synclist) {
                        var b = s.synclist[a];
                        b && b.call(s);
                        s.synclist[a] = !1;
                    }
                }), v = !0);
            }();
            return a;
        };
        this.unsynched = function (a) {
            s.synclist[a] && (s.synclist[a] = !1);
        };
        this.css = function (a, b) {
            for (var c in b) s.saved.css.push([a, c, a.css(c)]), a.css(c, b[c]);
        };
        this.scrollTop = function (a) {
            return "undefined" == typeof a ? s.getScrollTop() : s.setScrollTop(a);
        };
        this.scrollLeft = function (a) {
            return "undefined" == typeof a ? s.getScrollLeft() : s.setScrollLeft(a);
        };
        BezierClass = function (a, b, c, d, e, f, g) {
            this.st = a;
            this.ed = b;
            this.spd = c;
            this.p1 = d || 0;
            this.p2 = e || 1;
            this.p3 = f || 0;
            this.p4 = g || 1;
            this.ts = new Date().getTime();
            this.df = this.ed - this.st;
        };
        BezierClass.prototype = {
            B2: function (a) {
                return 3 * a * a * (1 - a);
            },
            B3: function (a) {
                return 3 * a * (1 - a) * (1 - a);
            },
            B4: function (a) {
                return (1 - a) * (1 - a) * (1 - a);
            },
            getNow: function () {
                var a = 1 - (new Date().getTime() - this.ts) / this.spd, b = this.B2(a) + this.B3(a) + this.B4(a);
                return 0 > a ? this.ed : this.st + Math.round(this.df * b);
            },
            update: function (a, b) {
                this.st = this.getNow();
                this.ed = a;
                this.spd = b;
                this.ts = new Date().getTime();
                this.df = this.ed - this.st;
                return this;
            }
        };
        if (this.ishwscroll) {
            this.doc.translate = {
                x: 0,
                y: 0,
                tx: "0px",
                ty: "0px"
            };
            u.hastranslate3d && u.isios && this.doc.css("-webkit-backface-visibility", "hidden");
            var w = function () {
                var a = s.doc.css(u.trstyle);
                return a && "matrix" == a.substr(0, 6) ? a.replace(/^.*\((.*)\)$/g, "$1").replace(/px/g, "").split(/, +/) : !1;
            };
            this.getScrollTop = function (a) {
                if (!a) {
                    if (a = w()) return 16 == a.length ? -a[13] : -a[5];
                    if (s.timerscroll && s.timerscroll.bz) return s.timerscroll.bz.getNow();
                }
                return s.doc.translate.y;
            };
            this.getScrollLeft = function (a) {
                if (!a) {
                    if (a = w()) return 16 == a.length ? -a[12] : -a[4];
                    if (s.timerscroll && s.timerscroll.bh) return s.timerscroll.bh.getNow();
                }
                return s.doc.translate.x;
            };
            this.notifyScrollEvent = document.createEvent ? function (a) {
                var b = document.createEvent("UIEvents");
                b.initUIEvent("scroll", !1, !0, window, 1);
                a.dispatchEvent(b);
            } : document.fireEvent ? function (a) {
                var b = document.createEventObject();
                a.fireEvent("onscroll");
                b.cancelBubble = !0;
            } : function (a, b) { };
            u.hastranslate3d && s.opt.enabletranslate3d ? (this.setScrollTop = function (a, b) {
                s.doc.translate.y = a;
                s.doc.translate.ty = -1 * a + "px";
                s.doc.css(u.trstyle, "translate3d(" + s.doc.translate.tx + "," + s.doc.translate.ty + ",0px)");
                b || s.notifyScrollEvent(s.win[0]);
            }, this.setScrollLeft = function (a, b) {
                s.doc.translate.x = a;
                s.doc.translate.tx = -1 * a + "px";
                s.doc.css(u.trstyle, "translate3d(" + s.doc.translate.tx + "," + s.doc.translate.ty + ",0px)");
                b || s.notifyScrollEvent(s.win[0]);
            }) : (this.setScrollTop = function (a, b) {
                s.doc.translate.y = a;
                s.doc.translate.ty = -1 * a + "px";
                s.doc.css(u.trstyle, "translate(" + s.doc.translate.tx + "," + s.doc.translate.ty + ")");
                b || s.notifyScrollEvent(s.win[0]);
            }, this.setScrollLeft = function (a, b) {
                s.doc.translate.x = a;
                s.doc.translate.tx = -1 * a + "px";
                s.doc.css(u.trstyle, "translate(" + s.doc.translate.tx + "," + s.doc.translate.ty + ")");
                b || s.notifyScrollEvent(s.win[0]);
            });
        } else this.getScrollTop = function () {
            return s.docscroll.scrollTop();
        }, this.setScrollTop = function (a) {
            return s.docscroll.scrollTop(a);
        }, this.getScrollLeft = function () {
            return s.docscroll.scrollLeft();
        }, this.setScrollLeft = function (a) {
            return s.docscroll.scrollLeft(a);
        };
        this.getTarget = function (a) {
            return !a ? !1 : a.target ? a.target : a.srcElement ? a.srcElement : !1;
        };
        this.hasParent = function (a, b) {
            if (!a) return !1;
            for (var c = a.target || a.srcElement || a || !1; c && c.id != b;) c = c.parentNode || !1;
            return !1 !== c;
        };
        var x = {
            thin: 1,
            medium: 3,
            thick: 5
        };
        this.getOffset = function () {
            if (s.isfixed) return {
                top: parseFloat(s.win.css("top")),
                left: parseFloat(s.win.css("left"))
            };
            if (!s.viewport) return s.win.offset();
            var a = s.win.offset(), b = s.viewport.offset();
            return {
                top: a.top - b.top + s.viewport.scrollTop(),
                left: a.left - b.left + s.viewport.scrollLeft()
            };
        };
        this.updateScrollBar = function (a) {
            if (s.ishwscroll) s.rail.css({
                height: s.win.innerHeight()
            }), s.railh && s.railh.css({
                width: s.win.innerWidth()
            }); else {
                var b = s.getOffset(), c = b.top, d = b.left, c = c + n(s.win, "border-top-width", !0);
                s.win.outerWidth();
                s.win.innerWidth();
                var d = d + (s.rail.align ? s.win.outerWidth() - n(s.win, "border-right-width") - s.rail.width : n(s.win, "border-left-width")), e = s.opt.railoffset;
                e && (e.top && (c += e.top), s.rail.align && e.left && (d += e.left));
                s.locked || s.rail.css({
                    top: c,
                    left: d,
                    height: a ? a.h : s.win.innerHeight()
                });
                s.zoom && s.zoom.css({
                    top: c + 1,
                    left: 1 == s.rail.align ? d - 20 : d + s.rail.width + 4
                });
                s.railh && !s.locked && (c = b.top, d = b.left, a = s.railh.align ? c + n(s.win, "border-top-width", !0) + s.win.innerHeight() - s.railh.height : c + n(s.win, "border-top-width", !0),
                d += n(s.win, "border-left-width"), s.railh.css({
                    top: a,
                    left: d,
                    width: s.railh.width
                }));
            }
        };
        this.doRailClick = function (a, b, c) {
            var d;
            s.locked || (s.cancelEvent(a), b ? (b = c ? s.doScrollLeft : s.doScrollTop, d = c ? (a.pageX - s.railh.offset().left - s.cursorwidth / 2) * s.scrollratio.x : (a.pageY - s.rail.offset().top - s.cursorheight / 2) * s.scrollratio.y,
            b(d)) : (b = c ? s.doScrollLeftBy : s.doScrollBy, d = c ? s.scroll.x : s.scroll.y,
            a = c ? a.pageX - s.railh.offset().left : a.pageY - s.rail.offset().top, c = c ? s.view.w : s.view.h,
            d >= a ? b(c) : b(-c)));
        };
        s.hasanimationframe = h;
        s.hascancelanimationframe = i;
        s.hasanimationframe ? s.hascancelanimationframe || (i = function () {
            s.cancelAnimationFrame = !0;
        }) : (h = function (a) {
            return setTimeout(a, 15 - Math.floor(+new Date() / 1e3) % 16);
        }, i = clearInterval);
        this.init = function () {
            s.saved.css = [];
            if (u.isie7mobile || u.isoperamini) return !0;
            u.hasmstouch && s.css(s.ispage ? a("html") : s.win, {
                "-ms-touch-action": "none"
            });
            s.zindex = "auto";
            s.zindex = !s.ispage && "auto" == s.opt.zindex ? k() || "auto" : s.opt.zindex;
            !s.ispage && "auto" != s.zindex && s.zindex > f && (f = s.zindex);
            s.isie && 0 == s.zindex && "auto" == s.opt.zindex && (s.zindex = "auto");
            if (!s.ispage || !u.cantouch && !u.isieold && !u.isie9mobile) {
                var e = s.docscroll;
                s.ispage && (e = s.haswrapper ? s.win : s.doc);
                u.isie9mobile || s.css(e, {
                    "overflow-y": "hidden"
                });
                s.ispage && u.isie7 && ("BODY" == s.doc[0].nodeName ? s.css(a("html"), {
                    "overflow-y": "hidden"
                }) : "HTML" == s.doc[0].nodeName && s.css(a("body"), {
                    "overflow-y": "hidden"
                }));
                u.isios && !s.ispage && !s.haswrapper && s.css(a("body"), {
                    "-webkit-overflow-scrolling": "touch"
                });
                var g = a(document.createElement("div"));
                g.css({
                    position: "relative",
                    top: 0,
                    "float": "right",
                    width: s.opt.cursorwidth,
                    height: "0px",
                    "background-color": s.opt.cursorcolor,
                    border: s.opt.cursorborder,
                    "background-clip": "padding-box",
                    "-webkit-border-radius": s.opt.cursorborderradius,
                    "-moz-border-radius": s.opt.cursorborderradius,
                    "border-radius": s.opt.cursorborderradius
                });
                g.hborder = parseFloat(g.outerHeight() - g.innerHeight());
                s.cursor = g;
                var h = a(document.createElement("div"));
                h.attr("id", s.id);
                h.addClass("nicescroll-rails");
                var i, j, m = ["left", "right"], n;
                for (n in m) j = m[n], (i = s.opt.railpadding[j]) ? h.css("padding-" + j, i + "px") : s.opt.railpadding[j] = 0;
                h.append(g);
                h.width = Math.max(parseFloat(s.opt.cursorwidth), g.outerWidth()) + s.opt.railpadding.left + s.opt.railpadding.right;
                h.css({
                    width: h.width + "px",
                    zIndex: s.zindex,
                    background: s.opt.background,
                    cursor: "default"
                });
                h.visibility = !0;
                h.scrollable = !0;
                h.align = "left" == s.opt.railalign ? 0 : 1;
                s.rail = h;
                g = s.rail.drag = !1;
                s.opt.boxzoom && !s.ispage && !u.isieold && (g = document.createElement("div"),
                s.bind(g, "click", s.doZoom), s.zoom = a(g), s.zoom.css({
                    cursor: "pointer",
                    "z-index": s.zindex,
                    backgroundImage: "url(" + s.opt.scriptpath + "zoomico.png)",
                    height: 18,
                    width: 18,
                    backgroundPosition: "0px 0px"
                }), s.opt.dblclickzoom && s.bind(s.win, "dblclick", s.doZoom), u.cantouch && s.opt.gesturezoom && (s.ongesturezoom = function (a) {
                    1.5 < a.scale && s.doZoomIn(a);
                    .8 > a.scale && s.doZoomOut(a);
                    return s.cancelEvent(a);
                }, s.bind(s.win, "gestureend", s.ongesturezoom)));
                s.railh = !1;
                if (s.opt.horizrailenabled) {
                    s.css(e, {
                        "overflow-x": "hidden"
                    });
                    g = a(document.createElement("div"));
                    g.css({
                        position: "relative",
                        top: 0,
                        height: s.opt.cursorwidth,
                        width: "0px",
                        "background-color": s.opt.cursorcolor,
                        border: s.opt.cursorborder,
                        "background-clip": "padding-box",
                        "-webkit-border-radius": s.opt.cursorborderradius,
                        "-moz-border-radius": s.opt.cursorborderradius,
                        "border-radius": s.opt.cursorborderradius
                    });
                    g.wborder = parseFloat(g.outerWidth() - g.innerWidth());
                    s.cursorh = g;
                    var o = a(document.createElement("div"));
                    o.attr("id", s.id + "-hr");
                    o.addClass("nicescroll-rails");
                    o.height = Math.max(parseFloat(s.opt.cursorwidth), g.outerHeight());
                    o.css({
                        height: o.height + "px",
                        zIndex: s.zindex,
                        background: s.opt.background
                    });
                    o.append(g);
                    o.visibility = !0;
                    o.scrollable = !0;
                    o.align = "top" == s.opt.railvalign ? 0 : 1;
                    s.railh = o;
                    s.railh.drag = !1;
                }
                s.ispage ? (h.css({
                    position: "fixed",
                    top: "0px",
                    height: "100%"
                }), h.align ? h.css({
                    right: "0px"
                }) : h.css({
                    left: "0px"
                }), s.body.append(h), s.railh && (o.css({
                    position: "fixed",
                    left: "0px",
                    width: "100%"
                }), o.align ? o.css({
                    bottom: "0px"
                }) : o.css({
                    top: "0px"
                }), s.body.append(o))) : (s.ishwscroll ? ("static" == s.win.css("position") && s.css(s.win, {
                    position: "relative"
                }), e = "HTML" == s.win[0].nodeName ? s.body : s.win, s.zoom && (s.zoom.css({
                    position: "absolute",
                    top: 1,
                    right: 0,
                    "margin-right": h.width + 4
                }), e.append(s.zoom)), h.css({
                    position: "absolute",
                    top: 0
                }), h.align ? h.css({
                    right: 0
                }) : h.css({
                    left: 0
                }), e.append(h), o && (o.css({
                    position: "absolute",
                    left: 0,
                    bottom: 0
                }), o.align ? o.css({
                    bottom: 0
                }) : o.css({
                    top: 0
                }), e.append(o))) : (s.isfixed = "fixed" == s.win.css("position"), e = s.isfixed ? "fixed" : "absolute",
                s.isfixed || (s.viewport = s.getViewport(s.win[0])), s.viewport && (s.body = s.viewport,
                !1 == /fixed|relative|absolute/.test(s.viewport.css("position")) && s.css(s.viewport, {
                    position: "relative"
                })), h.css({
                    position: e
                }), s.zoom && s.zoom.css({
                    position: e
                }), s.updateScrollBar(), s.body.append(h), s.zoom && s.body.append(s.zoom), s.railh && (o.css({
                    position: e
                }), s.body.append(o))), u.isios && s.css(s.win, {
                    "-webkit-tap-highlight-color": "rgba(0,0,0,0)",
                    "-webkit-touch-callout": "none"
                }), u.isie && s.opt.disableoutline && s.win.attr("hideFocus", "true"), u.iswebkit && s.opt.disableoutline && s.win.css({
                    outline: "none"
                }));
                !1 === s.opt.autohidemode ? (s.autohidedom = !1, s.rail.css({
                    opacity: s.opt.cursoropacitymax
                }), s.railh && s.railh.css({
                    opacity: s.opt.cursoropacitymax
                })) : !0 === s.opt.autohidemode || "leave" === s.opt.autohidemode ? (s.autohidedom = a().add(s.rail),
                u.isie8 && (s.autohidedom = s.autohidedom.add(s.cursor)), s.railh && (s.autohidedom = s.autohidedom.add(s.railh)),
                s.railh && u.isie8 && (s.autohidedom = s.autohidedom.add(s.cursorh))) : "scroll" == s.opt.autohidemode ? (s.autohidedom = a().add(s.rail),
                s.railh && (s.autohidedom = s.autohidedom.add(s.railh))) : "cursor" == s.opt.autohidemode ? (s.autohidedom = a().add(s.cursor),
                s.railh && (s.autohidedom = s.autohidedom.add(s.cursorh))) : "hidden" == s.opt.autohidemode && (s.autohidedom = !1,
                s.hide(), s.locked = !1);
                if (u.isie9mobile) s.scrollmom = new q(s), s.onmangotouch = function (a) {
                    a = s.getScrollTop();
                    var b = s.getScrollLeft();
                    if (a == s.scrollmom.lastscrolly && b == s.scrollmom.lastscrollx) return !0;
                    var c = a - s.mangotouch.sy, d = b - s.mangotouch.sx;
                    if (0 != Math.round(Math.sqrt(Math.pow(d, 2) + Math.pow(c, 2)))) {
                        var e = 0 > c ? -1 : 1, f = 0 > d ? -1 : 1, g = +new Date();
                        s.mangotouch.lazy && clearTimeout(s.mangotouch.lazy);
                        80 < g - s.mangotouch.tm || s.mangotouch.dry != e || s.mangotouch.drx != f ? (s.scrollmom.stop(),
                        s.scrollmom.reset(b, a), s.mangotouch.sy = a, s.mangotouch.ly = a, s.mangotouch.sx = b,
                        s.mangotouch.lx = b, s.mangotouch.dry = e, s.mangotouch.drx = f, s.mangotouch.tm = g) : (s.scrollmom.stop(),
                        s.scrollmom.update(s.mangotouch.sx - d, s.mangotouch.sy - c), s.mangotouch.tm = g,
                        c = Math.max(Math.abs(s.mangotouch.ly - a), Math.abs(s.mangotouch.lx - b)), s.mangotouch.ly = a,
                        s.mangotouch.lx = b, 2 < c && (s.mangotouch.lazy = setTimeout(function () {
                            s.mangotouch.lazy = !1;
                            s.mangotouch.dry = 0;
                            s.mangotouch.drx = 0;
                            s.mangotouch.tm = 0;
                            s.scrollmom.doMomentum(30);
                        }, 100)));
                    }
                }, h = s.getScrollTop(), o = s.getScrollLeft(), s.mangotouch = {
                    sy: h,
                    ly: h,
                    dry: 0,
                    sx: o,
                    lx: o,
                    drx: 0,
                    lazy: !1,
                    tm: 0
                }, s.bind(s.docscroll, "scroll", s.onmangotouch); else {
                    if (u.cantouch || s.istouchcapable || s.opt.touchbehavior || u.hasmstouch) {
                        s.scrollmom = new q(s);
                        s.ontouchstart = function (b) {
                            if (b.pointerType && 2 != b.pointerType) return !1;
                            s.hasmoving = !1;
                            if (!s.locked) {
                                if (u.hasmstouch) for (var c = b.target ? b.target : !1; c;) {
                                    var d = a(c).getNiceScroll();
                                    if (0 < d.length && d[0].me == s.me) break;
                                    if (0 < d.length) return !1;
                                    if ("DIV" == c.nodeName && c.id == s.id) break;
                                    c = c.parentNode ? c.parentNode : !1;
                                }
                                s.cancelScroll();
                                if ((c = s.getTarget(b)) && /INPUT/i.test(c.nodeName) && /range/i.test(c.type)) return s.stopPropagation(b);
                                !("clientX" in b) && "changedTouches" in b && (b.clientX = b.changedTouches[0].clientX,
                                b.clientY = b.changedTouches[0].clientY);
                                s.forcescreen && (d = b, b = {
                                    original: b.original ? b.original : b
                                }, b.clientX = d.screenX, b.clientY = d.screenY);
                                s.rail.drag = {
                                    x: b.clientX,
                                    y: b.clientY,
                                    sx: s.scroll.x,
                                    sy: s.scroll.y,
                                    st: s.getScrollTop(),
                                    sl: s.getScrollLeft(),
                                    pt: 2,
                                    dl: !1
                                };
                                if (s.ispage || !s.opt.directionlockdeadzone) s.rail.drag.dl = "f"; else {
                                    var d = a(window).width(), e = a(window).height(), f = Math.max(document.body.scrollWidth, document.documentElement.scrollWidth), g = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight), e = Math.max(0, g - e), d = Math.max(0, f - d);
                                    s.rail.drag.ck = !s.rail.scrollable && s.railh.scrollable ? 0 < e ? "v" : !1 : s.rail.scrollable && !s.railh.scrollable ? 0 < d ? "h" : !1 : !1;
                                    s.rail.drag.ck || (s.rail.drag.dl = "f");
                                }
                                s.opt.touchbehavior && s.isiframe && u.isie && (d = s.win.position(), s.rail.drag.x += d.left,
                                s.rail.drag.y += d.top);
                                s.hasmoving = !1;
                                s.lastmouseup = !1;
                                s.scrollmom.reset(b.clientX, b.clientY);
                                if (!u.cantouch && !this.istouchcapable && !u.hasmstouch) {
                                    if (!c || !/INPUT|SELECT|TEXTAREA/i.test(c.nodeName)) return !s.ispage && u.hasmousecapture && c.setCapture(),
                                    s.opt.touchbehavior ? (c.onclick && !c._onclick && (c._onclick = c.onclick, c.onclick = function (a) {
                                        if (s.hasmoving) return !1;
                                        c._onclick.call(this, a);
                                    }), s.cancelEvent(b)) : s.stopPropagation(b);
                                    /SUBMIT|CANCEL|BUTTON/i.test(a(c).attr("type")) && (pc = {
                                        tg: c,
                                        click: !1
                                    }, s.preventclick = pc);
                                }
                            }
                        };
                        s.ontouchend = function (a) {
                            if (a.pointerType && 2 != a.pointerType) return !1;
                            if (s.rail.drag && 2 == s.rail.drag.pt && (s.scrollmom.doMomentum(), s.rail.drag = !1,
                            s.hasmoving && (s.lastmouseup = !0, s.hideCursor(), u.hasmousecapture && document.releaseCapture(),
                            !u.cantouch))) return s.cancelEvent(a);
                        };
                        var p = s.opt.touchbehavior && s.isiframe && !u.hasmousecapture;
                        s.ontouchmove = function (b, c) {
                            if (b.pointerType && 2 != b.pointerType) return !1;
                            if (s.rail.drag && 2 == s.rail.drag.pt) {
                                if (u.cantouch && "undefined" == typeof b.original) return !0;
                                s.hasmoving = !0;
                                s.preventclick && !s.preventclick.click && (s.preventclick.click = s.preventclick.tg.onclick || !1,
                                s.preventclick.tg.onclick = s.onpreventclick);
                                b = a.extend({
                                    original: b
                                }, b);
                                "changedTouches" in b && (b.clientX = b.changedTouches[0].clientX, b.clientY = b.changedTouches[0].clientY);
                                if (s.forcescreen) {
                                    var d = b;
                                    b = {
                                        original: b.original ? b.original : b
                                    };
                                    b.clientX = d.screenX;
                                    b.clientY = d.screenY;
                                }
                                d = ofy = 0;
                                if (p && !c) {
                                    var e = s.win.position(), d = -e.left;
                                    ofy = -e.top;
                                }
                                var f = b.clientY + ofy, e = f - s.rail.drag.y, g = b.clientX + d, h = g - s.rail.drag.x, i = s.rail.drag.st - e;
                                s.ishwscroll && s.opt.bouncescroll ? 0 > i ? i = Math.round(i / 2) : i > s.page.maxh && (i = s.page.maxh + Math.round((i - s.page.maxh) / 2)) : (0 > i && (f = i = 0),
                                i > s.page.maxh && (i = s.page.maxh, f = 0));
                                if (s.railh && s.railh.scrollable) {
                                    var j = s.rail.drag.sl - h;
                                    s.ishwscroll && s.opt.bouncescroll ? 0 > j ? j = Math.round(j / 2) : j > s.page.maxw && (j = s.page.maxw + Math.round((j - s.page.maxw) / 2)) : (0 > j && (g = j = 0),
                                    j > s.page.maxw && (j = s.page.maxw, g = 0));
                                }
                                d = !1;
                                if (s.rail.drag.dl) d = !0, "v" == s.rail.drag.dl ? j = s.rail.drag.sl : "h" == s.rail.drag.dl && (i = s.rail.drag.st); else {
                                    var e = Math.abs(e), h = Math.abs(h), k = s.opt.directionlockdeadzone;
                                    if ("v" == s.rail.drag.ck) {
                                        if (e > k && h <= .3 * e) return s.rail.drag = !1, !0;
                                        h > k && (s.rail.drag.dl = "f", a("body").scrollTop(a("body").scrollTop()));
                                    } else if ("h" == s.rail.drag.ck) {
                                        if (h > k && e <= .3 * h) return s.rail.drag = !1, !0;
                                        e > k && (s.rail.drag.dl = "f", a("body").scrollLeft(a("body").scrollLeft()));
                                    }
                                }
                                s.synched("touchmove", function () {
                                    s.rail.drag && 2 == s.rail.drag.pt && (s.prepareTransition && s.prepareTransition(0),
                                    s.rail.scrollable && s.setScrollTop(i), s.scrollmom.update(g, f), s.railh && s.railh.scrollable ? (s.setScrollLeft(j),
                                    s.showCursor(i, j)) : s.showCursor(i), u.isie10 && document.selection.clear());
                                });
                                u.ischrome && s.istouchcapable && (d = !1);
                                if (d) return s.cancelEvent(b);
                            }
                        };
                    }
                    s.onmousedown = function (a, b) {
                        if (!(s.rail.drag && 1 != s.rail.drag.pt)) {
                            if (s.locked) return s.cancelEvent(a);
                            s.cancelScroll();
                            s.rail.drag = {
                                x: a.clientX,
                                y: a.clientY,
                                sx: s.scroll.x,
                                sy: s.scroll.y,
                                pt: 1,
                                hr: !!b
                            };
                            var c = s.getTarget(a);
                            !s.ispage && u.hasmousecapture && c.setCapture();
                            s.isiframe && !u.hasmousecapture && (s.saved.csspointerevents = s.doc.css("pointer-events"),
                            s.css(s.doc, {
                                "pointer-events": "none"
                            }));
                            s.hasmoving = !1;
                            return s.cancelEvent(a);
                        }
                    };
                    s.onmouseup = function (a) {
                        if (s.rail.drag && (u.hasmousecapture && document.releaseCapture(), s.isiframe && !u.hasmousecapture && s.doc.css("pointer-events", s.saved.csspointerevents),
                        1 == s.rail.drag.pt)) return s.rail.drag = !1, s.hasmoving && s.triggerScrollEnd(),
                        s.cancelEvent(a);
                    };
                    s.onmousemove = function (a) {
                        if (s.rail.drag && 1 == s.rail.drag.pt) {
                            if (u.ischrome && 0 == a.which) return s.onmouseup(a);
                            s.cursorfreezed = !0;
                            s.hasmoving = !0;
                            if (s.rail.drag.hr) {
                                s.scroll.x = s.rail.drag.sx + (a.clientX - s.rail.drag.x);
                                0 > s.scroll.x && (s.scroll.x = 0);
                                var b = s.scrollvaluemaxw;
                                s.scroll.x > b && (s.scroll.x = b);
                            } else s.scroll.y = s.rail.drag.sy + (a.clientY - s.rail.drag.y), 0 > s.scroll.y && (s.scroll.y = 0),
                            b = s.scrollvaluemax, s.scroll.y > b && (s.scroll.y = b);
                            s.synched("mousemove", function () {
                                s.rail.drag && 1 == s.rail.drag.pt && (s.showCursor(), s.rail.drag.hr ? s.doScrollLeft(Math.round(s.scroll.x * s.scrollratio.x), s.opt.cursordragspeed) : s.doScrollTop(Math.round(s.scroll.y * s.scrollratio.y), s.opt.cursordragspeed));
                            });
                            return s.cancelEvent(a);
                        }
                    };
                    if (u.cantouch || s.opt.touchbehavior) s.onpreventclick = function (a) {
                        if (s.preventclick) return s.preventclick.tg.onclick = s.preventclick.click, s.preventclick = !1,
                        s.cancelEvent(a);
                    }, s.bind(s.win, "mousedown", s.ontouchstart), s.onclick = u.isios ? !1 : function (a) {
                        return s.lastmouseup ? (s.lastmouseup = !1, s.cancelEvent(a)) : !0;
                    }, s.opt.grabcursorenabled && u.cursorgrabvalue && (s.css(s.ispage ? s.doc : s.win, {
                        cursor: u.cursorgrabvalue
                    }), s.css(s.rail, {
                        cursor: u.cursorgrabvalue
                    })); else {
                        var r = function (a) {
                            if (s.selectiondrag) {
                                if (a) {
                                    var b = s.win.outerHeight();
                                    a = a.pageY - s.selectiondrag.top;
                                    0 < a && a < b && (a = 0);
                                    a >= b && (a -= b);
                                    s.selectiondrag.df = a;
                                }
                                0 != s.selectiondrag.df && (s.doScrollBy(2 * -Math.floor(s.selectiondrag.df / 6)),
                                s.debounced("doselectionscroll", function () {
                                    r();
                                }, 50));
                            }
                        };
                        s.hasTextSelected = "getSelection" in document ? function () {
                            return 0 < document.getSelection().rangeCount;
                        } : "selection" in document ? function () {
                            return "None" != document.selection.type;
                        } : function () {
                            return !1;
                        };
                        s.onselectionstart = function (a) {
                            s.ispage || (s.selectiondrag = s.win.offset());
                        };
                        s.onselectionend = function (a) {
                            s.selectiondrag = !1;
                        };
                        s.onselectiondrag = function (a) {
                            s.selectiondrag && s.hasTextSelected() && s.debounced("selectionscroll", function () {
                                r(a);
                            }, 250);
                        };
                    }
                    u.hasmstouch && (s.css(s.rail, {
                        "-ms-touch-action": "none"
                    }), s.css(s.cursor, {
                        "-ms-touch-action": "none"
                    }), s.bind(s.win, "MSPointerDown", s.ontouchstart), s.bind(document, "MSPointerUp", s.ontouchend),
                    s.bind(document, "MSPointerMove", s.ontouchmove), s.bind(s.cursor, "MSGestureHold", function (a) {
                        a.preventDefault();
                    }), s.bind(s.cursor, "contextmenu", function (a) {
                        a.preventDefault();
                    }));
                    this.istouchcapable && (s.bind(s.win, "touchstart", s.ontouchstart), s.bind(document, "touchend", s.ontouchend),
                    s.bind(document, "touchcancel", s.ontouchend), s.bind(document, "touchmove", s.ontouchmove));
                    s.bind(s.cursor, "mousedown", s.onmousedown);
                    s.bind(s.cursor, "mouseup", s.onmouseup);
                    s.railh && (s.bind(s.cursorh, "mousedown", function (a) {
                        s.onmousedown(a, !0);
                    }), s.bind(s.cursorh, "mouseup", s.onmouseup));
                    if (s.opt.cursordragontouch || !u.cantouch && !s.opt.touchbehavior) s.rail.css({
                        cursor: "default"
                    }), s.railh && s.railh.css({
                        cursor: "default"
                    }), s.jqbind(s.rail, "mouseenter", function () {
                        if (!s.win.is(":visible")) return !1;
                        s.canshowonmouseevent && s.showCursor();
                        s.rail.active = !0;
                    }), s.jqbind(s.rail, "mouseleave", function () {
                        s.rail.active = !1;
                        s.rail.drag || s.hideCursor();
                    }), s.opt.sensitiverail && (s.bind(s.rail, "click", function (a) {
                        s.doRailClick(a, !1, !1);
                    }), s.bind(s.rail, "dblclick", function (a) {
                        s.doRailClick(a, !0, !1);
                    }), s.bind(s.cursor, "click", function (a) {
                        s.cancelEvent(a);
                    }), s.bind(s.cursor, "dblclick", function (a) {
                        s.cancelEvent(a);
                    })), s.railh && (s.jqbind(s.railh, "mouseenter", function () {
                        if (!s.win.is(":visible")) return !1;
                        s.canshowonmouseevent && s.showCursor();
                        s.rail.active = !0;
                    }), s.jqbind(s.railh, "mouseleave", function () {
                        s.rail.active = !1;
                        s.rail.drag || s.hideCursor();
                    }), s.opt.sensitiverail && (s.bind(s.railh, "click", function (a) {
                        s.doRailClick(a, !1, !0);
                    }), s.bind(s.railh, "dblclick", function (a) {
                        s.doRailClick(a, !0, !0);
                    }), s.bind(s.cursorh, "click", function (a) {
                        s.cancelEvent(a);
                    }), s.bind(s.cursorh, "dblclick", function (a) {
                        s.cancelEvent(a);
                    })));
                    !u.cantouch && !s.opt.touchbehavior ? (s.bind(u.hasmousecapture ? s.win : document, "mouseup", s.onmouseup),
                    s.bind(document, "mousemove", s.onmousemove), s.onclick && s.bind(document, "click", s.onclick),
                    !s.ispage && s.opt.enablescrollonselection && (s.bind(s.win[0], "mousedown", s.onselectionstart),
                    s.bind(document, "mouseup", s.onselectionend), s.bind(s.cursor, "mouseup", s.onselectionend),
                    s.cursorh && s.bind(s.cursorh, "mouseup", s.onselectionend), s.bind(document, "mousemove", s.onselectiondrag)),
                    s.zoom && (s.jqbind(s.zoom, "mouseenter", function () {
                        s.canshowonmouseevent && s.showCursor();
                        s.rail.active = !0;
                    }), s.jqbind(s.zoom, "mouseleave", function () {
                        s.rail.active = !1;
                        s.rail.drag || s.hideCursor();
                    }))) : (s.bind(u.hasmousecapture ? s.win : document, "mouseup", s.ontouchend), s.bind(document, "mousemove", s.ontouchmove),
                    s.onclick && s.bind(document, "click", s.onclick), s.opt.cursordragontouch && (s.bind(s.cursor, "mousedown", s.onmousedown),
                    s.bind(s.cursor, "mousemove", s.onmousemove), s.cursorh && s.bind(s.cursorh, "mousedown", function (a) {
                        s.onmousedown(a, !0);
                    }), s.cursorh && s.bind(s.cursorh, "mousemove", s.onmousemove)));
                    s.opt.enablemousewheel && (s.isiframe || s.bind(u.isie && s.ispage ? document : s.win, "mousewheel", s.onmousewheel),
                    s.bind(s.rail, "mousewheel", s.onmousewheel), s.railh && s.bind(s.railh, "mousewheel", s.onmousewheelhr));
                    !s.ispage && !u.cantouch && !/HTML|^BODY/.test(s.win[0].nodeName) && (s.win.attr("tabindex") || s.win.attr({
                        tabindex: d++
                    }), s.jqbind(s.win, "focus", function (a) {
                        b = s.getTarget(a).id || !0;
                        s.hasfocus = !0;
                        s.canshowonmouseevent && s.noticeCursor();
                    }), s.jqbind(s.win, "blur", function (a) {
                        b = !1;
                        s.hasfocus = !1;
                    }), s.jqbind(s.win, "mouseenter", function (a) {
                        c = s.getTarget(a).id || !0;
                        s.hasmousefocus = !0;
                        s.canshowonmouseevent && s.noticeCursor();
                    }), s.jqbind(s.win, "mouseleave", function () {
                        c = !1;
                        s.hasmousefocus = !1;
                        s.rail.drag || s.hideCursor();
                    }));
                }
                s.onkeypress = function (d) {
                    if (s.locked && 0 == s.page.maxh) return !0;
                    d = d ? d : window.e;
                    var e = s.getTarget(d);
                    if (e && /INPUT|TEXTAREA|SELECT|OPTION/.test(e.nodeName) && (!e.getAttribute("type") && !e.type || !/submit|button|cancel/i.tp) || a(e).attr("contenteditable")) return !0;
                    if (s.hasfocus || s.hasmousefocus && !b || s.ispage && !b && !c) {
                        e = d.keyCode;
                        if (s.locked && 27 != e) return s.cancelEvent(d);
                        var f = d.ctrlKey || !1, g = d.shiftKey || !1, h = !1;
                        switch (e) {
                            case 38:
                            case 63233:
                                s.doScrollBy(72);
                                h = !0;
                                break;

                            case 40:
                            case 63235:
                                s.doScrollBy(-72);
                                h = !0;
                                break;

                            case 37:
                            case 63232:
                                s.railh && (f ? s.doScrollLeft(0) : s.doScrollLeftBy(72), h = !0);
                                break;

                            case 39:
                            case 63234:
                                s.railh && (f ? s.doScrollLeft(s.page.maxw) : s.doScrollLeftBy(-72), h = !0);
                                break;

                            case 33:
                            case 63276:
                                s.doScrollBy(s.view.h);
                                h = !0;
                                break;

                            case 34:
                            case 63277:
                                s.doScrollBy(-s.view.h);
                                h = !0;
                                break;

                            case 36:
                            case 63273:
                                s.railh && f ? s.doScrollPos(0, 0) : s.doScrollTo(0);
                                h = !0;
                                break;

                            case 35:
                            case 63275:
                                s.railh && f ? s.doScrollPos(s.page.maxw, s.page.maxh) : s.doScrollTo(s.page.maxh);
                                h = !0;
                                break;

                            case 32:
                                s.opt.spacebarenabled && (g ? s.doScrollBy(s.view.h) : s.doScrollBy(-s.view.h),
                                h = !0);
                                break;

                            case 27:
                                s.zoomactive && (s.doZoom(), h = !0);
                        }
                        if (h) return s.cancelEvent(d);
                    }
                };
                s.opt.enablekeyboard && s.bind(document, u.isopera && !u.isopera12 ? "keypress" : "keydown", s.onkeypress);
                s.bind(document, "keydown", function (a) {
                    a.ctrlKey && (s.wheelprevented = !0);
                });
                s.bind(document, "keyup", function (a) {
                    a.ctrlKey || (s.wheelprevented = !1);
                });
                s.bind(window, "resize", s.lazyResize);
                s.bind(window, "orientationchange", s.lazyResize);
                s.bind(window, "load", s.lazyResize);
                if (u.ischrome && !s.ispage && !s.haswrapper) {
                    var t = s.win.attr("style"), h = parseFloat(s.win.css("width")) + 1;
                    s.win.css("width", h);
                    s.synched("chromefix", function () {
                        s.win.attr("style", t);
                    });
                }
                s.onAttributeChange = function (a) {
                    s.lazyResize(250);
                };
                !s.ispage && !s.haswrapper && (!1 !== l ? (s.observer = new l(function (a) {
                    a.forEach(s.onAttributeChange);
                }), s.observer.observe(s.win[0], {
                    childList: !0,
                    characterData: !1,
                    attributes: !0,
                    subtree: !1
                }), s.observerremover = new l(function (a) {
                    a.forEach(function (a) {
                        if (0 < a.removedNodes.length) for (var b in a.removedNodes) if (a.removedNodes[b] == s.win[0]) return s.remove();
                    });
                }), s.observerremover.observe(s.win[0].parentNode, {
                    childList: !0,
                    characterData: !1,
                    attributes: !1,
                    subtree: !1
                })) : (s.bind(s.win, u.isie && !u.isie9 ? "propertychange" : "DOMAttrModified", s.onAttributeChange),
                u.isie9 && s.win[0].attachEvent("onpropertychange", s.onAttributeChange), s.bind(s.win, "DOMNodeRemoved", function (a) {
                    a.target == s.win[0] && s.remove();
                })));
                !s.ispage && s.opt.boxzoom && s.bind(window, "resize", s.resizeZoom);
                s.istextarea && s.bind(s.win, "mouseup", s.lazyResize);
                s.lazyResize(30);
            }
            if ("IFRAME" == this.doc[0].nodeName) {
                var v = function (b) {
                    s.iframexd = !1;
                    try {
                        var c = "contentDocument" in this ? this.contentDocument : this.contentWindow.document;
                    } catch (d) {
                        s.iframexd = !0, c = !1;
                    }
                    if (s.iframexd) return "console" in window && console.log("NiceScroll error: policy restriced iframe"),
                    !0;
                    s.forcescreen = !0;
                    s.isiframe && (s.iframe = {
                        doc: a(c),
                        html: s.doc.contents().find("html")[0],
                        body: s.doc.contents().find("body")[0]
                    }, s.getContentSize = function () {
                        return {
                            w: Math.max(s.iframe.html.scrollWidth, s.iframe.body.scrollWidth),
                            h: Math.max(s.iframe.html.scrollHeight, s.iframe.body.scrollHeight)
                        };
                    }, s.docscroll = a(s.iframe.body));
                    !u.isios && s.opt.iframeautoresize && !s.isiframe && (s.win.scrollTop(0), s.doc.height(""),
                    b = Math.max(c.getElementsByTagName("html")[0].scrollHeight, c.body.scrollHeight),
                    s.doc.height(b));
                    s.lazyResize(30);
                    u.isie7 && s.css(a(s.iframe.html), {
                        "overflow-y": "hidden"
                    });
                    s.css(a(s.iframe.body), {
                        "overflow-y": "hidden"
                    });
                    u.isios && s.haswrapper && s.css(a(c.body), {
                        "-webkit-transform": "translate3d(0,0,0)"
                    });
                    "contentWindow" in this ? s.bind(this.contentWindow, "scroll", s.onscroll) : s.bind(c, "scroll", s.onscroll);
                    s.opt.enablemousewheel && s.bind(c, "mousewheel", s.onmousewheel);
                    s.opt.enablekeyboard && s.bind(c, u.isopera ? "keypress" : "keydown", s.onkeypress);
                    if (u.cantouch || s.opt.touchbehavior) s.bind(c, "mousedown", s.ontouchstart), s.bind(c, "mousemove", function (a) {
                        s.ontouchmove(a, !0);
                    }), s.opt.grabcursorenabled && u.cursorgrabvalue && s.css(a(c.body), {
                        cursor: u.cursorgrabvalue
                    });
                    s.bind(c, "mouseup", s.ontouchend);
                    s.zoom && (s.opt.dblclickzoom && s.bind(c, "dblclick", s.doZoom), s.ongesturezoom && s.bind(c, "gestureend", s.ongesturezoom));
                };
                this.doc[0].readyState && "complete" == this.doc[0].readyState && setTimeout(function () {
                    v.call(s.doc[0], !1);
                }, 500);
                s.bind(this.doc, "load", v);
            }
        };
        this.showCursor = function (a, b) {
            s.cursortimeout && (clearTimeout(s.cursortimeout), s.cursortimeout = 0);
            if (s.rail) {
                s.autohidedom && (s.autohidedom.stop().css({
                    opacity: s.opt.cursoropacitymax
                }), s.cursoractive = !0);
                if (!s.rail.drag || 1 != s.rail.drag.pt) "undefined" != typeof a && !1 !== a && (s.scroll.y = Math.round(1 * a / s.scrollratio.y)),
                "undefined" != typeof b && (s.scroll.x = Math.round(1 * b / s.scrollratio.x));
                s.cursor.css({
                    height: s.cursorheight,
                    top: s.scroll.y
                });
                s.cursorh && (!s.rail.align && s.rail.visibility ? s.cursorh.css({
                    width: s.cursorwidth,
                    left: s.scroll.x + s.rail.width
                }) : s.cursorh.css({
                    width: s.cursorwidth,
                    left: s.scroll.x
                }), s.cursoractive = !0);
                s.zoom && s.zoom.stop().css({
                    opacity: s.opt.cursoropacitymax
                });
            }
        };
        this.hideCursor = function (a) {
            !s.cursortimeout && s.rail && s.autohidedom && !(s.hasmousefocus && "leave" == s.opt.autohidemode) && (s.cursortimeout = setTimeout(function () {
                if (!s.rail.active || !s.showonmouseevent) s.autohidedom.stop().animate({
                    opacity: s.opt.cursoropacitymin
                }), s.zoom && s.zoom.stop().animate({
                    opacity: s.opt.cursoropacitymin
                }), s.cursoractive = !1;
                s.cursortimeout = 0;
            }, a || s.opt.hidecursordelay));
        };
        this.noticeCursor = function (a, b, c) {
            s.showCursor(b, c);
            s.rail.active || s.hideCursor(a);
        };
        this.getContentSize = s.ispage ? function () {
            return {
                w: Math.max(document.body.scrollWidth, document.documentElement.scrollWidth),
                h: Math.max(document.body.scrollHeight, document.documentElement.scrollHeight)
            };
        } : s.haswrapper ? function () {
            return {
                w: s.doc.outerWidth() + parseInt(s.win.css("paddingLeft")) + parseInt(s.win.css("paddingRight")),
                h: s.doc.outerHeight() + parseInt(s.win.css("paddingTop")) + parseInt(s.win.css("paddingBottom"))
            };
        } : function () {
            return {
                w: s.docscroll[0].scrollWidth,
                h: s.docscroll[0].scrollHeight
            };
        };
        this.onResize = function (a, b) {
            if (!s || !s.win) return !1;
            if (!s.haswrapper && !s.ispage) {
                if ("none" == s.win.css("display")) return s.visibility && s.hideRail().hideRailHr(),
                !1;
                !s.hidden && !s.visibility && s.showRail().showRailHr();
            }
            var c = s.page.maxh, d = s.page.maxw, e = s.view.w;
            s.view = {
                w: s.ispage ? s.win.width() : parseInt(s.win[0].clientWidth),
                h: s.ispage ? s.win.height() : parseInt(s.win[0].clientHeight)
            };
            s.page = b ? b : s.getContentSize();
            s.page.maxh = Math.max(0, s.page.h - s.view.h);
            s.page.maxw = Math.max(0, s.page.w - s.view.w);
            if (s.page.maxh == c && s.page.maxw == d && s.view.w == e) {
                if (s.ispage) return s;
                c = s.win.offset();
                if (s.lastposition && (d = s.lastposition, d.top == c.top && d.left == c.left)) return s;
                s.lastposition = c;
            }
            0 == s.page.maxh ? (s.hideRail(), s.scrollvaluemax = 0, s.scroll.y = 0, s.scrollratio.y = 0,
            s.cursorheight = 0, s.setScrollTop(0), s.rail.scrollable = !1) : s.rail.scrollable = !0;
            0 == s.page.maxw ? (s.hideRailHr(), s.scrollvaluemaxw = 0, s.scroll.x = 0, s.scrollratio.x = 0,
            s.cursorwidth = 0, s.setScrollLeft(0), s.railh.scrollable = !1) : s.railh.scrollable = !0;
            s.locked = 0 == s.page.maxh && 0 == s.page.maxw;
            if (s.locked) return s.ispage || s.updateScrollBar(s.view), !1;
            !s.hidden && !s.visibility ? s.showRail().showRailHr() : !s.hidden && !s.railh.visibility && s.showRailHr();
            s.istextarea && s.win.css("resize") && "none" != s.win.css("resize") && (s.view.h -= 20);
            s.cursorheight = Math.min(s.view.h, Math.round(s.view.h * (s.view.h / s.page.h)));
            s.cursorheight = s.opt.cursorfixedheight ? s.opt.cursorfixedheight : Math.max(s.opt.cursorminheight, s.cursorheight);
            s.cursorwidth = Math.min(s.view.w, Math.round(s.view.w * (s.view.w / s.page.w)));
            s.cursorwidth = s.opt.cursorfixedheight ? s.opt.cursorfixedheight : Math.max(s.opt.cursorminheight, s.cursorwidth);
            s.scrollvaluemax = s.view.h - s.cursorheight - s.cursor.hborder;
            s.railh && (s.railh.width = 0 < s.page.maxh ? s.view.w - s.rail.width : s.view.w,
            s.scrollvaluemaxw = s.railh.width - s.cursorwidth - s.cursorh.wborder);
            s.ispage || s.updateScrollBar(s.view);
            s.scrollratio = {
                x: s.page.maxw / s.scrollvaluemaxw,
                y: s.page.maxh / s.scrollvaluemax
            };
            s.getScrollTop() > s.page.maxh ? s.doScrollTop(s.page.maxh) : (s.scroll.y = Math.round(s.getScrollTop() * (1 / s.scrollratio.y)),
            s.scroll.x = Math.round(s.getScrollLeft() * (1 / s.scrollratio.x)), s.cursoractive && s.noticeCursor());
            s.scroll.y && 0 == s.getScrollTop() && s.doScrollTo(Math.floor(s.scroll.y * s.scrollratio.y));
            return s;
        };
        this.resize = s.onResize;
        this.lazyResize = function (a) {
            a = isNaN(a) ? 30 : a;
            s.delayed("resize", s.resize, a);
            return s;
        };
        this._bind = function (a, b, c, d) {
            s.events.push({
                e: a,
                n: b,
                f: c,
                b: d,
                q: !1
            });
            a.addEventListener ? a.addEventListener(b, c, d || !1) : a.attachEvent ? a.attachEvent("on" + b, c) : a["on" + b] = c;
        };
        this.jqbind = function (b, c, d) {
            s.events.push({
                e: b,
                n: c,
                f: d,
                q: !0
            });
            a(b).bind(c, d);
        };
        this.bind = function (a, b, c, d) {
            var e = "jquery" in a ? a[0] : a;
            "mousewheel" == b ? "onwheel" in s.win ? s._bind(e, "wheel", c, d || !1) : (a = "undefined" != typeof document.onmousewheel ? "mousewheel" : "DOMMouseScroll",
            p(e, a, c, d || !1), "DOMMouseScroll" == a && p(e, "MozMousePixelScroll", c, d || !1)) : e.addEventListener ? (u.cantouch && /mouseup|mousedown|mousemove/.test(b) && s._bind(e, "mousedown" == b ? "touchstart" : "mouseup" == b ? "touchend" : "touchmove", function (a) {
                if (a.touches) {
                    if (2 > a.touches.length) {
                        var b = a.touches.length ? a.touches[0] : a;
                        b.original = a;
                        c.call(this, b);
                    }
                } else a.changedTouches && (b = a.changedTouches[0], b.original = a, c.call(this, b));
            }, d || !1), s._bind(e, b, c, d || !1), u.cantouch && "mouseup" == b && s._bind(e, "touchcancel", c, d || !1)) : s._bind(e, b, function (a) {
                if ((a = a || window.event || !1) && a.srcElement) a.target = a.srcElement;
                "pageY" in a || (a.pageX = a.clientX + document.documentElement.scrollLeft, a.pageY = a.clientY + document.documentElement.scrollTop);
                return !1 === c.call(e, a) || !1 === d ? s.cancelEvent(a) : !0;
            });
        };
        this._unbind = function (a, b, c, d) {
            a.removeEventListener ? a.removeEventListener(b, c, d) : a.detachEvent ? a.detachEvent("on" + b, c) : a["on" + b] = !1;
        };
        this.unbindAll = function () {
            for (var a = 0; a < s.events.length; a++) {
                var b = s.events[a];
                b.q ? b.e.unbind(b.n, b.f) : s._unbind(b.e, b.n, b.f, b.b);
            }
        };
        this.cancelEvent = function (a) {
            a = a.original ? a.original : a ? a : window.event || !1;
            if (!a) return !1;
            a.preventDefault && a.preventDefault();
            a.stopPropagation && a.stopPropagation();
            a.preventManipulation && a.preventManipulation();
            a.cancelBubble = !0;
            a.cancel = !0;
            return a.returnValue = !1;
        };
        this.stopPropagation = function (a) {
            a = a.original ? a.original : a ? a : window.event || !1;
            if (!a) return !1;
            if (a.stopPropagation) return a.stopPropagation();
            a.cancelBubble && (a.cancelBubble = !0);
            return !1;
        };
        this.showRail = function () {
            if (0 != s.page.maxh && (s.ispage || "none" != s.win.css("display"))) s.visibility = !0,
            s.rail.visibility = !0, s.rail.css("display", "block");
            return s;
        };
        this.showRailHr = function () {
            if (!s.railh) return s;
            if (0 != s.page.maxw && (s.ispage || "none" != s.win.css("display"))) s.railh.visibility = !0,
            s.railh.css("display", "block");
            return s;
        };
        this.hideRail = function () {
            s.visibility = !1;
            s.rail.visibility = !1;
            s.rail.css("display", "none");
            return s;
        };
        this.hideRailHr = function () {
            if (!s.railh) return s;
            s.railh.visibility = !1;
            s.railh.css("display", "none");
            return s;
        };
        this.show = function () {
            s.hidden = !1;
            s.locked = !1;
            return s.showRail().showRailHr();
        };
        this.hide = function () {
            s.hidden = !0;
            s.locked = !0;
            return s.hideRail().hideRailHr();
        };
        this.toggle = function () {
            return s.hidden ? s.show() : s.hide();
        };
        this.remove = function () {
            s.stop();
            s.cursortimeout && clearTimeout(s.cursortimeout);
            s.doZoomOut();
            s.unbindAll();
            u.isie9 && s.win[0].detachEvent("onpropertychange", s.onAttributeChange);
            !1 !== s.observer && s.observer.disconnect();
            !1 !== s.observerremover && s.observerremover.disconnect();
            s.events = null;
            s.cursor && s.cursor.remove();
            s.cursorh && s.cursorh.remove();
            s.rail && s.rail.remove();
            s.railh && s.railh.remove();
            s.zoom && s.zoom.remove();
            for (var b = 0; b < s.saved.css.length; b++) {
                var c = s.saved.css[b];
                c[0].css(c[1], "undefined" == typeof c[2] ? "" : c[2]);
            }
            s.saved = !1;
            s.me.data("__nicescroll", "");
            var d = a.nicescroll;
            d.each(function (a) {
                if (this && this.id === s.id) {
                    delete d[a];
                    for (var b = ++a; b < d.length; b++, a++) d[a] = d[b];
                    d.length--;
                    d.length && delete d[d.length];
                }
            });
            for (var e in s) s[e] = null, delete s[e];
            s = null;
        };
        this.scrollstart = function (a) {
            this.onscrollstart = a;
            return s;
        };
        this.scrollend = function (a) {
            this.onscrollend = a;
            return s;
        };
        this.scrollcancel = function (a) {
            this.onscrollcancel = a;
            return s;
        };
        this.zoomin = function (a) {
            this.onzoomin = a;
            return s;
        };
        this.zoomout = function (a) {
            this.onzoomout = a;
            return s;
        };
        this.isScrollable = function (b) {
            b = b.target ? b.target : b;
            if ("OPTION" == b.nodeName) return !0;
            for (; b && 1 == b.nodeType && !/^BODY|HTML/.test(b.nodeName) ;) {
                var c = a(b), c = c.css("overflowY") || c.css("overflowX") || c.css("overflow") || "";
                if (/scroll|auto/.test(c)) return b.clientHeight != b.scrollHeight;
                b = b.parentNode ? b.parentNode : !1;
            }
            return !1;
        };
        this.getViewport = function (b) {
            for (b = b && b.parentNode ? b.parentNode : !1; b && 1 == b.nodeType && !/^BODY|HTML/.test(b.nodeName) ;) {
                var c = a(b);
                if (/fixed|absolute/.test(c.css("position"))) return c;
                var d = c.css("overflowY") || c.css("overflowX") || c.css("overflow") || "";
                if (/scroll|auto/.test(d) && b.clientHeight != b.scrollHeight || 0 < c.getNiceScroll().length) return c;
                b = b.parentNode ? b.parentNode : !1;
            }
            return b ? a(b) : !1;
        };
        this.triggerScrollEnd = function () {
            if (s.onscrollend) {
                var a = s.getScrollLeft(), b = s.getScrollTop();
                s.onscrollend.call(s, {
                    type: "scrollend",
                    current: {
                        x: a,
                        y: b
                    },
                    end: {
                        x: a,
                        y: b
                    }
                });
            }
        };
        this.onmousewheel = function (a) {
            if (!s.wheelprevented) {
                if (s.locked) return s.debounced("checkunlock", s.resize, 250), !0;
                if (s.rail.drag) return s.cancelEvent(a);
                "auto" == s.opt.oneaxismousemode && 0 != a.deltaX && (s.opt.oneaxismousemode = !1);
                if (s.opt.oneaxismousemode && 0 == a.deltaX && !s.rail.scrollable) return s.railh && s.railh.scrollable ? s.onmousewheelhr(a) : !0;
                var b = +new Date(), c = !1;
                s.opt.preservenativescrolling && s.checkarea + 600 < b && (s.nativescrollingarea = s.isScrollable(a),
                c = !0);
                s.checkarea = b;
                if (s.nativescrollingarea) return !0;
                if (a = r(a, !1, c)) s.checkarea = 0;
                return a;
            }
        };
        this.onmousewheelhr = function (a) {
            if (!s.wheelprevented) {
                if (s.locked || !s.railh.scrollable) return !0;
                if (s.rail.drag) return s.cancelEvent(a);
                var b = +new Date(), c = !1;
                s.opt.preservenativescrolling && s.checkarea + 600 < b && (s.nativescrollingarea = s.isScrollable(a),
                c = !0);
                s.checkarea = b;
                return s.nativescrollingarea ? !0 : s.locked ? s.cancelEvent(a) : r(a, !0, c);
            }
        };
        this.stop = function () {
            s.cancelScroll();
            s.scrollmon && s.scrollmon.stop();
            s.cursorfreezed = !1;
            s.scroll.y = Math.round(s.getScrollTop() * (1 / s.scrollratio.y));
            s.noticeCursor();
            return s;
        };
        this.getTransitionSpeed = function (a) {
            var b = Math.round(10 * s.opt.scrollspeed);
            a = Math.min(b, Math.round(a / 20 * s.opt.scrollspeed));
            return 20 < a ? a : 0;
        };
        s.opt.smoothscroll ? s.ishwscroll && u.hastransition && s.opt.usetransition ? (this.prepareTransition = function (a, b) {
            var c = b ? 20 < a ? a : 0 : s.getTransitionSpeed(a), d = c ? u.prefixstyle + "transform " + c + "ms ease-out" : "";
            if (!s.lasttransitionstyle || s.lasttransitionstyle != d) s.lasttransitionstyle = d,
            s.doc.css(u.transitionstyle, d);
            return c;
        }, this.doScrollLeft = function (a, b) {
            var c = s.scrollrunning ? s.newscrolly : s.getScrollTop();
            s.doScrollPos(a, c, b);
        }, this.doScrollTop = function (a, b) {
            var c = s.scrollrunning ? s.newscrollx : s.getScrollLeft();
            s.doScrollPos(c, a, b);
        }, this.doScrollPos = function (a, b, c) {
            var d = s.getScrollTop(), e = s.getScrollLeft();
            (0 > (s.newscrolly - d) * (b - d) || 0 > (s.newscrollx - e) * (a - e)) && s.cancelScroll();
            !1 == s.opt.bouncescroll && (0 > b ? b = 0 : b > s.page.maxh && (b = s.page.maxh),
            0 > a ? a = 0 : a > s.page.maxw && (a = s.page.maxw));
            if (s.scrollrunning && a == s.newscrollx && b == s.newscrolly) return !1;
            s.newscrolly = b;
            s.newscrollx = a;
            s.newscrollspeed = c || !1;
            if (s.timer) return !1;
            s.timer = setTimeout(function () {
                var c = s.getScrollTop(), d = s.getScrollLeft(), e, f;
                e = a - d;
                f = b - c;
                e = Math.round(Math.sqrt(Math.pow(e, 2) + Math.pow(f, 2)));
                e = s.newscrollspeed && 1 < s.newscrollspeed ? s.newscrollspeed : s.getTransitionSpeed(e);
                s.newscrollspeed && 1 >= s.newscrollspeed && (e *= s.newscrollspeed);
                s.prepareTransition(e, !0);
                s.timerscroll && s.timerscroll.tm && clearInterval(s.timerscroll.tm);
                0 < e && (!s.scrollrunning && s.onscrollstart && s.onscrollstart.call(s, {
                    type: "scrollstart",
                    current: {
                        x: d,
                        y: c
                    },
                    request: {
                        x: a,
                        y: b
                    },
                    end: {
                        x: s.newscrollx,
                        y: s.newscrolly
                    },
                    speed: e
                }), u.transitionend ? s.scrollendtrapped || (s.scrollendtrapped = !0, s.bind(s.doc, u.transitionend, s.onScrollTransitionEnd, !1)) : (s.scrollendtrapped && clearTimeout(s.scrollendtrapped),
                s.scrollendtrapped = setTimeout(s.onScrollTransitionEnd, e)), s.timerscroll = {
                    bz: new BezierClass(c, s.newscrolly, e, 0, 0, .58, 1),
                    bh: new BezierClass(d, s.newscrollx, e, 0, 0, .58, 1)
                }, s.cursorfreezed || (s.timerscroll.tm = setInterval(function () {
                    s.showCursor(s.getScrollTop(), s.getScrollLeft());
                }, 60)));
                s.synched("doScroll-set", function () {
                    s.timer = 0;
                    s.scrollendtrapped && (s.scrollrunning = !0);
                    s.setScrollTop(s.newscrolly);
                    s.setScrollLeft(s.newscrollx);
                    if (!s.scrollendtrapped) s.onScrollTransitionEnd();
                });
            }, 50);
        }, this.cancelScroll = function () {
            if (!s.scrollendtrapped) return !0;
            var a = s.getScrollTop(), b = s.getScrollLeft();
            s.scrollrunning = !1;
            u.transitionend || clearTimeout(u.transitionend);
            s.scrollendtrapped = !1;
            s._unbind(s.doc, u.transitionend, s.onScrollTransitionEnd);
            s.prepareTransition(0);
            s.setScrollTop(a);
            s.railh && s.setScrollLeft(b);
            s.timerscroll && s.timerscroll.tm && clearInterval(s.timerscroll.tm);
            s.timerscroll = !1;
            s.cursorfreezed = !1;
            s.showCursor(a, b);
            return s;
        }, this.onScrollTransitionEnd = function () {
            s.scrollendtrapped && s._unbind(s.doc, u.transitionend, s.onScrollTransitionEnd);
            s.scrollendtrapped = !1;
            s.prepareTransition(0);
            s.timerscroll && s.timerscroll.tm && clearInterval(s.timerscroll.tm);
            s.timerscroll = !1;
            var a = s.getScrollTop(), b = s.getScrollLeft();
            s.setScrollTop(a);
            s.railh && s.setScrollLeft(b);
            s.noticeCursor(!1, a, b);
            s.cursorfreezed = !1;
            0 > a ? a = 0 : a > s.page.maxh && (a = s.page.maxh);
            0 > b ? b = 0 : b > s.page.maxw && (b = s.page.maxw);
            if (a != s.newscrolly || b != s.newscrollx) return s.doScrollPos(b, a, s.opt.snapbackspeed);
            s.onscrollend && s.scrollrunning && s.triggerScrollEnd();
            s.scrollrunning = !1;
        }) : (this.doScrollLeft = function (a, b) {
            var c = s.scrollrunning ? s.newscrolly : s.getScrollTop();
            s.doScrollPos(a, c, b);
        }, this.doScrollTop = function (a, b) {
            var c = s.scrollrunning ? s.newscrollx : s.getScrollLeft();
            s.doScrollPos(c, a, b);
        }, this.doScrollPos = function (a, b, c) {
            function d() {
                if (s.cancelAnimationFrame) return !0;
                s.scrollrunning = !0;
                if (l = 1 - l) return s.timer = h(d) || 1;
                var a = 0, b = sy = s.getScrollTop();
                if (s.dst.ay) {
                    var b = s.bzscroll ? s.dst.py + s.bzscroll.getNow() * s.dst.ay : s.newscrolly, c = b - sy;
                    if (0 > c && b < s.newscrolly || 0 < c && b > s.newscrolly) b = s.newscrolly;
                    s.setScrollTop(b);
                    b == s.newscrolly && (a = 1);
                } else a = 1;
                var e = sx = s.getScrollLeft();
                if (s.dst.ax) {
                    e = s.bzscroll ? s.dst.px + s.bzscroll.getNow() * s.dst.ax : s.newscrollx;
                    c = e - sx;
                    if (0 > c && e < s.newscrollx || 0 < c && e > s.newscrollx) e = s.newscrollx;
                    s.setScrollLeft(e);
                    e == s.newscrollx && (a += 1);
                } else a += 1;
                2 == a ? (s.timer = 0, s.cursorfreezed = !1, s.bzscroll = !1, s.scrollrunning = !1,
                0 > b ? b = 0 : b > s.page.maxh && (b = s.page.maxh), 0 > e ? e = 0 : e > s.page.maxw && (e = s.page.maxw),
                e != s.newscrollx || b != s.newscrolly ? s.doScrollPos(e, b) : s.onscrollend && s.triggerScrollEnd()) : s.timer = h(d) || 1;
            }
            b = "undefined" == typeof b || !1 === b ? s.getScrollTop(!0) : b;
            if (s.timer && s.newscrolly == b && s.newscrollx == a) return !0;
            s.timer && i(s.timer);
            s.timer = 0;
            var e = s.getScrollTop(), f = s.getScrollLeft();
            (0 > (s.newscrolly - e) * (b - e) || 0 > (s.newscrollx - f) * (a - f)) && s.cancelScroll();
            s.newscrolly = b;
            s.newscrollx = a;
            if (!s.bouncescroll || !s.rail.visibility) 0 > s.newscrolly ? s.newscrolly = 0 : s.newscrolly > s.page.maxh && (s.newscrolly = s.page.maxh);
            if (!s.bouncescroll || !s.railh.visibility) 0 > s.newscrollx ? s.newscrollx = 0 : s.newscrollx > s.page.maxw && (s.newscrollx = s.page.maxw);
            s.dst = {};
            s.dst.x = a - f;
            s.dst.y = b - e;
            s.dst.px = f;
            s.dst.py = e;
            var g = Math.round(Math.sqrt(Math.pow(s.dst.x, 2) + Math.pow(s.dst.y, 2)));
            s.dst.ax = s.dst.x / g;
            s.dst.ay = s.dst.y / g;
            var j = 0, k = g;
            0 == s.dst.x ? (j = e, k = b, s.dst.ay = 1, s.dst.py = 0) : 0 == s.dst.y && (j = f,
            k = a, s.dst.ax = 1, s.dst.px = 0);
            g = s.getTransitionSpeed(g);
            c && 1 >= c && (g *= c);
            s.bzscroll = 0 < g ? s.bzscroll ? s.bzscroll.update(k, g) : new BezierClass(j, k, g, 0, 1, 0, 1) : !1;
            if (!s.timer) {
                (e == s.page.maxh && b >= s.page.maxh || f == s.page.maxw && a >= s.page.maxw) && s.checkContentSize();
                var l = 1;
                s.cancelAnimationFrame = !1;
                s.timer = 1;
                s.onscrollstart && !s.scrollrunning && s.onscrollstart.call(s, {
                    type: "scrollstart",
                    current: {
                        x: f,
                        y: e
                    },
                    request: {
                        x: a,
                        y: b
                    },
                    end: {
                        x: s.newscrollx,
                        y: s.newscrolly
                    },
                    speed: g
                });
                d();
                (e == s.page.maxh && b >= e || f == s.page.maxw && a >= f) && s.checkContentSize();
                s.noticeCursor();
            }
        }, this.cancelScroll = function () {
            s.timer && i(s.timer);
            s.timer = 0;
            s.bzscroll = !1;
            s.scrollrunning = !1;
            return s;
        }) : (this.doScrollLeft = function (a, b) {
            var c = s.getScrollTop();
            s.doScrollPos(a, c, b);
        }, this.doScrollTop = function (a, b) {
            var c = s.getScrollLeft();
            s.doScrollPos(c, a, b);
        }, this.doScrollPos = function (a, b, c) {
            var d = a > s.page.maxw ? s.page.maxw : a;
            0 > d && (d = 0);
            var e = b > s.page.maxh ? s.page.maxh : b;
            0 > e && (e = 0);
            s.synched("scroll", function () {
                s.setScrollTop(e);
                s.setScrollLeft(d);
            });
        }, this.cancelScroll = function () { });
        this.doScrollBy = function (a, b) {
            var c = 0, c = b ? Math.floor((s.scroll.y - a) * s.scrollratio.y) : (s.timer ? s.newscrolly : s.getScrollTop(!0)) - a;
            if (s.bouncescroll) {
                var d = Math.round(s.view.h / 2);
                c < -d ? c = -d : c > s.page.maxh + d && (c = s.page.maxh + d);
            }
            s.cursorfreezed = !1;
            py = s.getScrollTop(!0);
            if (0 > c && 0 >= py) return s.noticeCursor();
            if (c > s.page.maxh && py >= s.page.maxh) return s.checkContentSize(), s.noticeCursor();
            s.doScrollTop(c);
        };
        this.doScrollLeftBy = function (a, b) {
            var c = 0, c = b ? Math.floor((s.scroll.x - a) * s.scrollratio.x) : (s.timer ? s.newscrollx : s.getScrollLeft(!0)) - a;
            if (s.bouncescroll) {
                var d = Math.round(s.view.w / 2);
                c < -d ? c = -d : c > s.page.maxw + d && (c = s.page.maxw + d);
            }
            s.cursorfreezed = !1;
            px = s.getScrollLeft(!0);
            if (0 > c && 0 >= px || c > s.page.maxw && px >= s.page.maxw) return s.noticeCursor();
            s.doScrollLeft(c);
        };
        this.doScrollTo = function (a, b) {
            b && Math.round(a * s.scrollratio.y);
            s.cursorfreezed = !1;
            s.doScrollTop(a);
        };
        this.checkContentSize = function () {
            var a = s.getContentSize();
            (a.h != s.page.h || a.w != s.page.w) && s.resize(!1, a);
        };
        s.onscroll = function (a) {
            s.rail.drag || s.cursorfreezed || s.synched("scroll", function () {
                s.scroll.y = Math.round(s.getScrollTop() * (1 / s.scrollratio.y));
                s.railh && (s.scroll.x = Math.round(s.getScrollLeft() * (1 / s.scrollratio.x)));
                s.noticeCursor();
            });
        };
        s.bind(s.docscroll, "scroll", s.onscroll);
        this.doZoomIn = function (b) {
            if (!s.zoomactive) {
                s.zoomactive = !0;
                s.zoomrestore = {
                    style: {}
                };
                var c = "position top left zIndex backgroundColor marginTop marginBottom marginLeft marginRight".split(" "), d = s.win[0].style, e;
                for (e in c) {
                    var g = c[e];
                    s.zoomrestore.style[g] = "undefined" != typeof d[g] ? d[g] : "";
                }
                s.zoomrestore.style.width = s.win.css("width");
                s.zoomrestore.style.height = s.win.css("height");
                s.zoomrestore.padding = {
                    w: s.win.outerWidth() - s.win.width(),
                    h: s.win.outerHeight() - s.win.height()
                };
                u.isios4 && (s.zoomrestore.scrollTop = a(window).scrollTop(), a(window).scrollTop(0));
                s.win.css({
                    position: u.isios4 ? "absolute" : "fixed",
                    top: 0,
                    left: 0,
                    "z-index": f + 100,
                    margin: "0px"
                });
                c = s.win.css("backgroundColor");
                ("" == c || /transparent|rgba\(0, 0, 0, 0\)|rgba\(0,0,0,0\)/.test(c)) && s.win.css("backgroundColor", "#fff");
                s.rail.css({
                    "z-index": f + 101
                });
                s.zoom.css({
                    "z-index": f + 102
                });
                s.zoom.css("backgroundPosition", "0px -18px");
                s.resizeZoom();
                s.onzoomin && s.onzoomin.call(s);
                return s.cancelEvent(b);
            }
        };
        this.doZoomOut = function (b) {
            if (s.zoomactive) return s.zoomactive = !1, s.win.css("margin", ""), s.win.css(s.zoomrestore.style),
            u.isios4 && a(window).scrollTop(s.zoomrestore.scrollTop), s.rail.css({
                "z-index": s.zindex
            }), s.zoom.css({
                "z-index": s.zindex
            }), s.zoomrestore = !1, s.zoom.css("backgroundPosition", "0px 0px"), s.onResize(),
            s.onzoomout && s.onzoomout.call(s), s.cancelEvent(b);
        };
        this.doZoom = function (a) {
            return s.zoomactive ? s.doZoomOut(a) : s.doZoomIn(a);
        };
        this.resizeZoom = function () {
            if (s.zoomactive) {
                var b = s.getScrollTop();
                s.win.css({
                    width: a(window).width() - s.zoomrestore.padding.w + "px",
                    height: a(window).height() - s.zoomrestore.padding.h + "px"
                });
                s.onResize();
                s.setScrollTop(Math.min(s.page.maxh, b));
            }
        };
        this.init();
        a.nicescroll.push(this);
    }, q = function (a) {
        var b = this;
        this.nc = a;
        this.steptime = this.lasttime = this.speedy = this.speedx = this.lasty = this.lastx = 0;
        this.snapy = this.snapx = !1;
        this.demuly = this.demulx = 0;
        this.lastscrolly = this.lastscrollx = -1;
        this.timer = this.chky = this.chkx = 0;
        this.time = function () {
            return +new Date();
        };
        this.reset = function (a, c) {
            b.stop();
            var d = b.time();
            b.steptime = 0;
            b.lasttime = d;
            b.speedx = 0;
            b.speedy = 0;
            b.lastx = a;
            b.lasty = c;
            b.lastscrollx = -1;
            b.lastscrolly = -1;
        };
        this.update = function (a, c) {
            var d = b.time();
            b.steptime = d - b.lasttime;
            b.lasttime = d;
            var d = c - b.lasty, e = a - b.lastx, f = b.nc.getScrollTop(), g = b.nc.getScrollLeft(), f = f + d, g = g + e;
            b.snapx = 0 > g || g > b.nc.page.maxw;
            b.snapy = 0 > f || f > b.nc.page.maxh;
            b.speedx = e;
            b.speedy = d;
            b.lastx = a;
            b.lasty = c;
        };
        this.stop = function () {
            b.nc.unsynched("domomentum2d");
            b.timer && clearTimeout(b.timer);
            b.timer = 0;
            b.lastscrollx = -1;
            b.lastscrolly = -1;
        };
        this.doSnapy = function (a, c) {
            var d = !1;
            0 > c ? (c = 0, d = !0) : c > b.nc.page.maxh && (c = b.nc.page.maxh, d = !0);
            0 > a ? (a = 0, d = !0) : a > b.nc.page.maxw && (a = b.nc.page.maxw, d = !0);
            d ? b.nc.doScrollPos(a, c, b.nc.opt.snapbackspeed) : b.nc.triggerScrollEnd();
        };
        this.doMomentum = function (a) {
            var c = b.time(), d = a ? c + a : b.lasttime;
            a = b.nc.getScrollLeft();
            var e = b.nc.getScrollTop(), f = b.nc.page.maxh, g = b.nc.page.maxw;
            b.speedx = 0 < g ? Math.min(60, b.speedx) : 0;
            b.speedy = 0 < f ? Math.min(60, b.speedy) : 0;
            d = d && 60 >= c - d;
            if (0 > e || e > f || 0 > a || a > g) d = !1;
            a = b.speedx && d ? b.speedx : !1;
            if (b.speedy && d && b.speedy || a) {
                var h = Math.max(16, b.steptime);
                50 < h && (a = h / 50, b.speedx *= a, b.speedy *= a, h = 50);
                b.demulxy = 0;
                b.lastscrollx = b.nc.getScrollLeft();
                b.chkx = b.lastscrollx;
                b.lastscrolly = b.nc.getScrollTop();
                b.chky = b.lastscrolly;
                var i = b.lastscrollx, j = b.lastscrolly, k = function () {
                    var a = 600 < b.time() - c ? .04 : .02;
                    if (b.speedx && (i = Math.floor(b.lastscrollx - b.speedx * (1 - b.demulxy)), b.lastscrollx = i,
                    0 > i || i > g)) a = .1;
                    if (b.speedy && (j = Math.floor(b.lastscrolly - b.speedy * (1 - b.demulxy)), b.lastscrolly = j,
                    0 > j || j > f)) a = .1;
                    b.demulxy = Math.min(1, b.demulxy + a);
                    b.nc.synched("domomentum2d", function () {
                        b.speedx && (b.nc.getScrollLeft() != b.chkx && b.stop(), b.chkx = i, b.nc.setScrollLeft(i));
                        b.speedy && (b.nc.getScrollTop() != b.chky && b.stop(), b.chky = j, b.nc.setScrollTop(j));
                        b.timer || (b.nc.hideCursor(), b.doSnapy(i, j));
                    });
                    1 > b.demulxy ? b.timer = setTimeout(k, h) : (b.stop(), b.nc.hideCursor(), b.doSnapy(i, j));
                };
                k();
            } else b.doSnapy(b.nc.getScrollLeft(), b.nc.getScrollTop());
        };
    }, r = a.fn.scrollTop;
    a.cssHooks.pageYOffset = {
        get: function (b, c, d) {
            return (c = a.data(b, "__nicescroll") || !1) && c.ishwscroll ? c.getScrollTop() : r.call(b);
        },
        set: function (b, c) {
            var d = a.data(b, "__nicescroll") || !1;
            d && d.ishwscroll ? d.setScrollTop(parseInt(c)) : r.call(b, c);
            return this;
        }
    };
    a.fn.scrollTop = function (b) {
        if ("undefined" == typeof b) {
            var c = this[0] ? a.data(this[0], "__nicescroll") || !1 : !1;
            return c && c.ishwscroll ? c.getScrollTop() : r.call(this);
        }
        return this.each(function () {
            var c = a.data(this, "__nicescroll") || !1;
            c && c.ishwscroll ? c.setScrollTop(parseInt(b)) : r.call(a(this), b);
        });
    };
    var s = a.fn.scrollLeft;
    a.cssHooks.pageXOffset = {
        get: function (b, c, d) {
            return (c = a.data(b, "__nicescroll") || !1) && c.ishwscroll ? c.getScrollLeft() : s.call(b);
        },
        set: function (b, c) {
            var d = a.data(b, "__nicescroll") || !1;
            d && d.ishwscroll ? d.setScrollLeft(parseInt(c)) : s.call(b, c);
            return this;
        }
    };
    a.fn.scrollLeft = function (b) {
        if ("undefined" == typeof b) {
            var c = this[0] ? a.data(this[0], "__nicescroll") || !1 : !1;
            return c && c.ishwscroll ? c.getScrollLeft() : s.call(this);
        }
        return this.each(function () {
            var c = a.data(this, "__nicescroll") || !1;
            c && c.ishwscroll ? c.setScrollLeft(parseInt(b)) : s.call(a(this), b);
        });
    };
    var t = function (b) {
        var c = this;
        this.length = 0;
        this.name = "nicescrollarray";
        this.each = function (a) {
            for (var b = 0, d = 0; b < c.length; b++) a.call(c[b], d++);
            return c;
        };
        this.push = function (a) {
            c[c.length] = a;
            c.length++;
        };
        this.eq = function (a) {
            return c[a];
        };
        if (b) for (var d = 0; d < b.length; d++) {
            var e = a.data(b[d], "__nicescroll") || !1;
            e && (this[this.length] = e, this.length++);
        }
        return this;
    };
    !function (a, b, c) {
        for (var d = 0; d < b.length; d++) c(a, b[d]);
    }(t.prototype, "show hide toggle onResize resize remove stop doScrollPos".split(" "), function (a, b) {
        a[b] = function () {
            var a = arguments;
            return this.each(function () {
                this[b].apply(this, a);
            });
        };
    });
    a.fn.getNiceScroll = function (b) {
        return "undefined" == typeof b ? new t(this) : this[b] && a.data(this[b], "__nicescroll") || !1;
    };
    a.extend(a.expr[":"], {
        nicescroll: function (b) {
            return a.data(b, "__nicescroll") ? !0 : !1;
        }
    });
    a.fn.niceScroll = function (b, c) {
        "undefined" == typeof c && "object" == typeof b && !("jquery" in b) && (c = b, b = !1);
        var d = new t();
        "undefined" == typeof c && (c = {});
        b && (c.doc = a(b), c.win = a(this));
        var e = !("doc" in c);
        !e && !("win" in c) && (c.win = a(this));
        this.each(function () {
            var b = a(this).data("__nicescroll") || !1;
            b || (c.doc = e ? a(this) : c.doc, b = new p(c, a(this)), a(this).data("__nicescroll", b));
            d.push(b);
        });
        return 1 == d.length ? d[0] : d;
    };
    window.NiceScroll = {
        getjQuery: function () {
            return a;
        }
    };
    a.nicescroll || (a.nicescroll = new t(), a.nicescroll.options = m);
});