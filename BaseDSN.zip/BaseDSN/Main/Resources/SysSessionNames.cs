﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Accent.Security.UI.Web.Resources
{
    public class SysSessionNames
    {
        public const string SessionSentToSelections = "SessionSentToSelections";
        public const string SessionSiteSearchSelectedResult = "SessionSiteSearchSelectedResult";
    }
}