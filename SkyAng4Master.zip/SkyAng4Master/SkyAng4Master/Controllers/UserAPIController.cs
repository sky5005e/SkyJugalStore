﻿using System.Data.Entity;
using System.Linq;
using System.Net.Http;
using System.Web.Http;

using SkyAng4Master.Data;
using System.Collections.Generic;

namespace Angular2MVC.Controllers
{
    public class UserAPIController : BaseAPIController
    {
        public HttpResponseMessage Get()
        {
            return ToJson(List()); //ErrorJson(List());//ToJson(List());
        }

        private List<UserInformation> List()
        {
            List<UserInformation> Users = new List<UserInformation>();
            for (int i = 1; i <= 500; i++)
            {
                UserInformation user = new UserInformation();
                user.FirstName = "FirstName" + i.ToString();
                user.LastName = "LastName" + i.ToString();
                user.Email = string.Format("Email{0}@gmail.com", i.ToString());
                Users.Add(user);
            }

            return Users;
        }

        public HttpResponseMessage Post([FromBody]UserInformation1 value)
        {
            DB.UserInformation1.Add(value);
            return ToJson(DB.SaveChanges());
        }

        public HttpResponseMessage Put(int id, [FromBody]UserInformation1 value)
        {
            DB.Entry(value).State = EntityState.Modified;
            return ToJson(DB.SaveChanges());
        }
        public HttpResponseMessage Delete(int id)
        {
            DB.UserInformation1.Remove(DB.UserInformation1.FirstOrDefault(x => x.UserId == id));
            return ToJson(DB.SaveChanges());
        }
    }
}
