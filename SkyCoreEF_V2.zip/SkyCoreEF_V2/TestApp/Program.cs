﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HicomCore;
using HicomCore.Entities;
namespace TestApp
{
    class Program
    {
        private static UnitOfWork unitOfWork;
        static void Main(string[] args)
        {
            try
            {

                Nullable<DateTime> dt = null;


                unitOfWork = new UnitOfWork();

                SecurityUser SecurityUser = unitOfWork.Repository<SecurityUser>().GetByID(3);
                if (SecurityUser == null)
                    SecurityUser = new SecurityUser();

                //SecurityUser.FirstName = "Nick";
                //SecurityUser.LastName = "Sharma";
                //SecurityUser.Username = "root@hicom.in";
                //SecurityUser.Email = "root@hicom.in";

                SecurityUser.FirstName = "Sky";
                SecurityUser.LastName = "Yadav";
                SecurityUser.Username = "root@hicom.com";
                SecurityUser.Email = "root@hicom.com";

                if (SecurityUser.SecurityUserId == 0)
                {
                    SecurityUser.Status = 1;
                    SecurityUser.PasswordFormat = 1;
                    SecurityUser.IsActive = true;
                    SecurityUser.CommunicationStatus = 0;
                    string salt = "wNyNLZ7HXE+7ihgBrprWiw==";
                    SecurityUser.Password = "3pGjLxoOBfNunUNqHgy9SkiDwm4=";
                    SecurityUser.LastPasswordChangedDateTime = DateTime.Now;
                    SecurityUser.PasswordSalt = salt;
                    SecurityUser.IsAnonymous = true;
                    SecurityUser.CreateOn = DateTime.Now;
                    SecurityUser.FailedPasswordAttemptCount = 0;
                    SecurityUser.ApplicationId = 1;

                    SecurityUser.Sys_LockedDateTime = dt;
                }

                SecurityUser.Sys_LockedDateTime = dt;

                if (SecurityUser.SecurityUserId > 0)
                    unitOfWork.Repository<SecurityUser>().Update(SecurityUser);
                else
                    unitOfWork.Repository<SecurityUser>().Insert(SecurityUser);

                unitOfWork.SaveChanges();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }

        }
    }
}
